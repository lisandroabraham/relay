# Pruebas

```bash
pnpm test            # unitarias + integración (servidor real) + convergencia
pnpm typecheck
pnpm test:e2e        # Playwright; requiere navegador (ver README)
RELAY_SEED=42 pnpm --filter @relay/web test   # reproducir un escenario de convergencia
```

## Qué cubre cada batería
| Batería | Qué comprueba |
|---|---|
| `apps/web/tests/limits.test.ts`, `bench.test.ts` | Umbrales de tamaño sobre bytes reales, fragmentación, copia compacta, y que el banco de `#/bench` se ejecuta y limpia su base |
| `apps/web/tests/persistence.test.ts` | Guardar/recargar, varios docs, no mezclar, no duplicar al reabrir, compactación, errores de almacenamiento (nunca «guardado» tras un fallo; reintento sin huecos), flag de sync conservado |
| `apps/web/tests/convergence.test.ts` | 6 pruebas de caracterización (apartado 5.3) + **150 escenarios deterministas** (2–4 réplicas, aislamiento, red parcial, entrega desordenada y duplicada, reconexión en orden arbitrario) |
| `apps/server/tests/validation.test.ts` | Validación de ids y orígenes, configuración |
| `apps/server/tests/sync.integration.test.ts` | Servidor y clientes **reales** por WebSocket: tiempo real, cliente tardío, desconexión de ambos y reconexión en distinto orden, reinicio del servidor, sala vacía, duplicados, oversize, malformados, origen/id, límites, tasa (cierre transitorio con recuperación), presencia/keepalive, cierre ordenado, rechazo permanente |
| `apps/web/e2e/*.spec.ts` | Navegador real (**escritas; sin ejecutar en el momento de escribir esto**) |

## Garantías verificadas y límites
- Se verifica **convergencia** de réplicas y ausencia de dependencias pendientes. 150 escenarios **no son una prueba formal**.
- **No** se verifica que el resultado coincida con la intención humana. Ver los tests de caracterización
  para el comportamiento observado (p. ej. edición simultánea del mismo fragmento: ambas versiones sobreviven mezcladas).
- Las pruebas de integración usan `localhost`: no cubren latencia real, pérdida de paquetes ni proxys.
- La persistencia se prueba con `fake-indexeddb`; el comportamiento de cuotas y durabilidad de navegadores reales no está cubierto.
- Un test de reposo de 75 s (idle) se ejecutó **a mano** y no forma parte de la batería (ver DECISIONS D6).
- Las mediciones de rendimiento están en `docs/BENCHMARKS.md` (entorno sintético, 1 CPU, `localhost`).

## Cómo comprobamos que las pruebas detectan fallos
Se hicieron pruebas de mutación manuales (sabotear el servidor/cliente y exigir que fallen): sin retransmisión,
sin límite de payload, sin validación de origen, reintento perpetuo, sala que no se destruye, entrega omitida
en el generador de convergencia, y volver permanente el cierre por tasa. Todas fueron detectadas.

## Añadir un escenario
Añade un caso a `convergence.test.ts` o un `it` en `sync.integration.test.ts` usando `startServer`/`makeClient`.
