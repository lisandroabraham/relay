# Mediciones y límites

**Condiciones.** Entorno de pruebas de Claude (no tu portátil): Node v22.22.2 · 1 CPU · 3997 MB RAM · Linux 6.18.44-fc-v139. Cliente y servidor en el mismo
proceso y en `localhost` (sin latencia de red real). Un solo servidor, 2 clientes salvo indicación.
Datos sintéticos (texto aleatorio de letras y espacios). Reproducir: `apps/server/bench/*.ts` con `npx tsx`.
**Esto NO son benchmarks de tu dispositivo ni del navegador**: para IndexedDB real abre `#/bench` (ver abajo).

## 1. Tamaño del estado completo de un documento (lo que recibe un cliente nuevo en un solo mensaje)

| Escenario | Caracteres | Operaciones | Estado completo | Bytes/carácter | Codificar | Aplicar en réplica nueva |
|---|---:|---:|---:|---:|---:|---:|
| pegado | 10.000 | 1 | 9.8 KiB | 1.00 | 1.0 ms | 1.2 ms |
| pegado | 100.000 | 1 | 97.7 KiB | 1.00 | 0.2 ms | 0.6 ms |
| pegado | 500.000 | 1 | 488.3 KiB | 1.00 | 1.3 ms | 0.8 ms |
| tecleo | 10.000 | 5017 | 9.8 KiB | 1.00 | 13.9 ms | 1.4 ms |
| tecleo | 100.001 | 50.003 | 97.7 KiB | 1.00 | 1.2 ms | 0.4 ms |
| tecleo | 500.000 | 250.071 | 488.3 KiB | 1.00 | 6.8 ms | 1.3 ms |
| ediciones al azar | 10.003 | 2197 | 65.6 KiB | 6.71 | 19.5 ms | 90.6 ms |
| ediciones al azar | 50.003 | 11.043 | 340.1 KiB | 6.96 | 51.2 ms | 172.0 ms |
| ediciones al azar | 150.003 | 33.313 | 1064.1 KiB | 7.26 | 60.8 ms | 163.1 ms |
| con muchos borrados | 10.000 | 9334 | 213.0 KiB | 21.81 | 73.8 ms | 135.0 ms |
| con muchos borrados | 30.000 | 28.001 | 675.8 KiB | 23.07 | 73.2 ms | 249.2 ms |
| con muchos borrados | 60.000 | 56.001 | 1239.0 KiB | 21.14 | 90.1 ms | 348.0 ms |

**Hallazgo principal:** el estado NO es proporcional al texto. Va de **~1 byte/carácter** (texto escrito de
seguido o pegado) a **~7** (ediciones en posiciones al azar) y a **~21-23** (muchos borrados: Yjs conserva una
marca por cada fragmento borrado). **Borrar texto aumenta el estado.** Por eso los límites se expresan en bytes
del estado real y no en caracteres.

## 2. Memoria del `Y.Doc` en el heap de Node (un proceso por escenario, tras GC)

| Escenario | Caracteres | Memoria de heap del Y.Doc | Por carácter |
|---|---:|---:|---:|
| pegado | 500.000 | 0.58 MiB | 1 B |
| tecleo | 500.001 | 9.27 MiB | 19 B |
| ediciones al azar | 50.000 | 4.30 MiB | 90 B |
| muchos borrados | 30.000 | 8.70 MiB | 304 B |

(Medida en Node, no en un navegador. La memoria real en un navegador será distinta. El escenario «pegado» guarda el texto como una sola cadena.)

## 3. Tiempo real con servidor real (localhost)

- **Latencia de una pulsación A→B:** p50 0,38 ms · p95 0,99 ms · máx 3,72 ms (350 muestras tras calentar). En la red real se sumará la latencia de red: este número solo descarta que nuestro código sea el cuello de botella.
- **Cliente que se une tarde** (documento pegado de una vez, ~1 byte/car.): 100.000 car. → 47 ms · 500.000 → 21 ms · 2.000.000 (1,9 MiB) → 22 ms. **No cubre documentos fragmentados:** en la tabla 1, aplicar un estado de ~1 MiB fragmentado cuesta 160–350 ms de CPU solo en el cliente.
- **Convergencia tras trabajar ambos sin conexión:** 200 operaciones por lado → 44 ms desde reconectar · 2.000 operaciones por lado → 145 ms.

## 4. Límites adoptados y su justificación

| Límite | Valor por defecto | Por qué |
|---|---|---|
| Estado máximo por documento en el cliente (`MAX_STATE_BYTES`) | 3 MiB | Un cliente nuevo recibe el estado completo en un solo mensaje; debe caber con margen en el límite del servidor |
| Tamaño máximo de mensaje WebSocket (`MAX_MESSAGE_BYTES`) | 4 MiB | Con 22 bytes/car. en el peor caso medido, 3 MiB ≈ 140.000 caracteres muy editados; más holgura de protocolo |
| Estado máximo por sala en el servidor (`MAX_ROOM_STATE_BYTES`) | 8 MiB | Cota de memoria por sala (se mide el estado real cada 64 KiB de tráfico) |
| Mensajes por segundo y conexión | 200 | Un humano genera decenas; un límite superado produce un cierre **transitorio** (4529) con reintento, no un rechazo |
| Conexiones por sala / salas / conexiones totales | 20 / 100 / 200 | Valores iniciales sin respaldo de carga real: **no hay pruebas de escalado** |

Límites **sin medir**: número de documentos abiertos a la vez, memoria total del servidor con muchas salas,
comportamiento con miles de conexiones. No afirmamos que el sistema escale.

## 5. Pendiente: mediciones en navegador real (las haces tú)

Abre `#/bench` en la app y pulsa «Ejecutar medición». Mide con IndexedDB real: crear documento, guardado
confirmado por edición (una transacción cada una), reabrir con 300 registros, pegado de 100.000 caracteres, y
tiempo de carga de la página. Usa una base temporal que se borra. **Pega aquí la tabla con las condiciones.**
