# Competencia y posicionamiento

Consultado el 17-10-2026. **Leyenda:** **[H]** hecho comprobado en documentación oficial o en el registro de
paquetes · **[T]** afirmación de un tercero (blog, comparativa), no verificada · **[Hip]** hipótesis nuestra ·
**[Op]** opinión mía. La búsqueda fue amplia pero **no exhaustiva**: no encontrar algo no prueba que no exista.

## Resumen honesto

1. El problema «guardar en local y sincronizar texto colaborativo sin conexión» está **resuelto y muy poblado**
   por proyectos de código abierto maduros y por servicios hospedados con plan gratuito. **[H]**
2. **El servidor que escribimos reimplementa funciones que ya ofrecen Hocuspocus y Y-Sweet** (autenticación,
   persistencia, extensiones, hospedaje). **[H]** No es una ventaja nuestra; es trabajo duplicado. **[Op]**
3. La app de notas con «simular sin conexión» **no se diferencia**: existen demos públicas casi idénticas. **[H]**
4. Lo que sí hemos construido y que no vi ofrecido como producto reutilizable para desarrolladores de apps con
   Yjs/Automerge: **un arnés de pruebas de sincronización** (escenarios deterministas con semilla, aislamiento,
   duplicados y desorden, contra servidor real) y **medición de los límites reales** (tamaño del estado vs. texto).
   **[Hip]** Existen simuladores deterministas, pero los que encontré son proyectos de un solo motor CRDT o
   herramientas internas (ver tabla). Hay que validarlo con desarrolladores antes de invertir más.

## Tabla

| Proyecto | Problema que resuelve | Tecnología | Puntos fuertes | Limitaciones documentadas | Público | Qué tendríamos que hacer mejor | Reutilizar o reimplementar |
|---|---|---|---|---|---|---|---|
| **Yjs** (+ y-websocket, y-indexeddb) | CRDT para datos compartidos y texto | CRDT YATA; proveedores de transporte y persistencia | Madurez, ecosistema, bindings de editores [H: npm, v13.6.33 activa] | `y-indexeddb` sin publicar desde 2023 y sin confirmar escrituras [H: lo verificamos leyendo su código]; el estado crece con el historial de edición [H: medido por nosotros] | Cualquier dev de apps colaborativas | — | **Reutilizar** (ya lo hacemos) |
| **Hocuspocus** (Tiptap) | Backend de colaboración para Yjs | Node, WebSocket, extensiones (p. ej. SQLite), hooks de conexión | MIT [H]; hospedaje propio u oferta cloud [H]; hooks de autenticación y persistencia [H: README] | Pensado para el ecosistema Tiptap («opinionated») [H] | Devs con editores Tiptap/ProseMirror | Nada: cubre lo que hace nuestro servidor | **Reutilizar en lugar de nuestro servidor** [Op] |
| **Y-Sweet** (Jamsocket) | Servidor Yjs con persistencia y autenticación | Rust (y-crdt); S3 o sistema de archivos; tokens; hooks React | MIT [H]; persistencia a S3 [H]; depurador [H] | Jamsocket pasó a formar parte de Modal Labs [H: su web]: riesgo de continuidad a vigilar [Op] | Devs que quieren Yjs con persistencia gestionada | Nada en servidor/persistencia | **Reutilizar** o usar su hospedaje |
| **Liveblocks** | Plataforma hospedada de colaboración (incl. Yjs) | SaaS; proveedor `@liveblocks/yjs` | Plan gratuito con 500 salas activas/mes, 10 conexiones por sala y 256 MB [H: docs de precios]; anuncia soporte offline [H: marketing, no verificado] | De pago al crecer; el límite del plan gratuito son 10 MB de datos por sala [H] | Equipos que quieren no operar infraestructura | No competimos en plataforma | **No reimplementar**: es un servicio, no una biblioteca |
| **Automerge / automerge-repo** | Motor de sincronización local-first | CRDT en Rust/WASM; adaptadores de almacenamiento y red | Se define a sí mismo como «PostgreSQL para apps local-first» [H]; Automerge 3 redujo la memoria ~10× [H: su blog]; guarda el historial completo [H] | En el registro de npm el tag `latest` de `automerge-repo` era una alpha el día de nuestra decisión [H] | Devs que quieren historial/versiones y P2P | Nada hoy | **Candidato a sustituir a Yjs** si importan historial, cifrado y control de acceso (revisar en semana 4) |
| **Zero** (Rocicorp) | Sincronización servidor-autoritativa sobre Postgres | Réplica local con consultas | Interacción muy rápida [H: su doc] | **No es local-first y no soporta escrituras sin conexión** [H: su propia documentación] | Apps con backend Postgres | — | No aplica a nuestro caso (offline) |
| **ElectricSQL / PowerSync** | Sincronizar una base de datos (Postgres, etc.) a clientes | Motores de sincronización de lectura/escritura sobre Postgres; SQLite en cliente | Muy citados en 2026 [T] | Orientados a datos relacionales, no a texto colaborativo [T] | Apps con backend SQL | No competimos | No aplica |
| **RxDB, TinyBase, Jazz, Triplit, InstantDB** | Bases de datos locales con sincronización | Varias | Listados como opciones local-first [T] | No evalué su documentación oficial | Apps de datos estructurados | No evaluado | No evaluado (**vacío de esta investigación**) |
| **Syncthing** | Sincronizar archivos entre dispositivos | Protocolo de intercambio de bloques; MPL-2.0 [H] | Sincronización continua de carpetas, P2P [H] | No fusiona el contenido de ediciones concurrentes: sincroniza archivos [H: su descripción] | Usuarios finales | No competimos | No aplica (referencia de P2P) |
| **Simuladores deterministas** (p. ej. `crdt-sync-engine`, `bones-sim`) | Probar convergencia con fallos de red y semilla reproducible | Simulador en proceso para su propio CRDT | Reproducción por semilla; invariantes (convergencia, idempotencia…) [H] | Atados a su propio motor [H]; no los vi como producto para apps con Yjs [Hip] | Autores de motores CRDT | Funcionar con **proveedores reales** (y-websocket, Hocuspocus…) y apps ajenas | **Referencia de diseño** |
| **Relay (lo nuestro)** | Notas offline + sincronización | Yjs + servidor propio | Persistencia con guardado confirmado; estados de UI definidos con precisión; límites medidos | Todo lo anterior: sin autenticación, sin persistencia en servidor, sin cifrado, sin escala probada | — | **Ver siguiente sección** | — |

Fuentes: github.com/ueberdosis/hocuspocus · github.com/jamsocket/y-sweet y docs.y-sweet.dev · jamsocket.xyz ·
liveblocks.io/docs/pricing/plans/free · automerge.org/blog/automerge-3 · zero.rocicorp.dev/docs/when-to-use ·
pkg.go.dev/github.com/syncthing/syncthing · github.com/66houdini/crdt-sync-engine · docs.rs/crate/bones-sim ·
registro de npm (versiones y fechas). Las comparativas de blogs (kanopylabs, buildmvpfast, cssauthor…) las
traté como **[T]**: son de calidad desigual y sus cifras de rendimiento no las usé.

## Posible diferenciación (hipótesis, no conclusión)

| Candidata | Evidencia a favor | Evidencia en contra / riesgo | Cómo validarla |
|---|---|---|---|
| **A. Arnés de pruebas de sincronización offline** para apps con Yjs: escenarios con semilla, aislamiento/duplicados/desorden/reinicio de servidor, invariantes, contra el proveedor real del usuario | Ya existe y detectó 2 fallos reales nuestros (cliente que se reconectaba cada 30 s; límite de tasa permanente) que las pruebas cortas no veían | Muchos equipos escriben su propia prueba; el mercado de «herramientas de prueba para devs» es pequeño y difícil de monetizar [Op] | Probarlo contra Hocuspocus y y-websocket sin cambiar el arnés; entrevistar a 8 devs con colaboración/offline |
| **B. Diagnóstico de límites de documentos Yjs** («doctor»: bytes/carácter, fragmentación, riesgo de superar límites, copia compacta) | Medimos que el estado va de 1 a ~22 bytes/carácter y que borrar lo aumenta; Liveblocks impone 10 MB por sala en su plan gratuito [H], así que el tamaño le importa a la gente | Podría ser una función de una biblioteca existente, no un producto [Op] | Preguntar a devs si han tenido problemas de tamaño en producción |
| **C. Indicadores de estado honestos como patrón** (guardado local confirmado vs. conectado vs. servidor recibido) | Implementado con definiciones exactas | Es una guía de UX, no tecnología diferenciada [Op] | Revisar apps existentes y comparar |

**Mi recomendación [Op]:** no seguir ampliando el servidor ni la app. Probar A (con B como complemento) antes de
decidir.
