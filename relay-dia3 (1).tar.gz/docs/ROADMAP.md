# Hoja de ruta (4 semanas) y conclusión honesta

Fechas: la semana 1 es 17–23 de octubre de 2026; las siguientes empiezan el sábado 24 de octubre.

## Conclusión provisional de la fase 1 (apartado 19.14 de la especificación)

**¿Merece continuar?** Sí, **pero solo con una hipótesis más estrecha**, y no la original.

- **Demostrado** (con pruebas automáticas contra un servidor real): editar sin conexión, guardar con
  confirmación, sincronizar entre clientes, reconectar tras desconexión o reinicio del servidor, y convergencia
  en 150 escenarios con semilla.
- **No demostrado:** que la idea tenga demanda; rendimiento en navegador real y en redes reales; escala.
- **Hipótesis original débil [Op]:** «app de notas + biblioteca de sincronización offline» compite con Yjs,
  Automerge, Hocuspocus, Y-Sweet y Liveblocks, todos maduros y con plan gratuito o código abierto (ver
  COMPETITION.md). Nuestro servidor duplica lo que ya existe.
- **Hipótesis a probar:** herramientas de prueba y diagnóstico de sincronización offline para desarrolladores
  que ya usan Yjs (candidatas A y B de COMPETITION.md).

## Plan

| Semana | Objetivo | Entregable verificable |
|---|---|---|
| **2** (24–30 oct) | Cerrar la verificación pendiente de la semana 1 y probar si el arnés es portable | E2E ejecutadas en navegador real; tabla de `#/bench` con condiciones; **las pruebas de integración pasan también contra Hocuspocus** (cambiando solo la URL/servidor) |
| **3** (31 oct–6 nov) | Extraer lo reutilizable y ponerlo delante de desarrolladores | `packages/sim`: simulador con fallos inyectables (pérdida, retraso, desorden, duplicado, partición, reinicio) sobre proveedores reales; comando para reproducir una semilla; ejemplo de integración con una app ajena; **5 entrevistas** a devs con colaboración u offline |
| **4** (7–13 nov) | Segunda ronda y medición | **8 entrevistas** acumuladas; ≥3 personas que completan el ejemplo y miden su tiempo de integración; lista de fallos que el arnés encontró en apps ajenas |
| **5** (14–20 nov) | **Puerta de decisión** | Informe con los criterios de abajo; decisión continuar / pivotar / parar |

## Criterios de decisión (fijados ahora, antes de ver resultados)

**Continuar** solo si se cumplen **todos**:
1. Al menos **3 de 8** desarrolladores con una necesidad real de offline o colaboración dicen que lo integrarían en
   un proyecto real en 30 días (no cuenta «me parece interesante»).
2. Al menos **2** completan el ejemplo de integración sin ayuda en **menos de 60 minutos**.
3. El arnés encuentra **al menos 1 fallo real** en una aplicación o servidor que no escribimos nosotros.

**Parar o pivotar** si: menos de 2 de 8 muestran interés concreto, o todos ya tienen una solución que consideran
suficiente, o el arnés no aporta nada sobre las pruebas que ya escriben.

## Qué NO haremos en estas semanas
Autenticación propia, persistencia en servidor, cifrado, WebRTC, más funciones de la app, monetización.
El servidor propio pasa a ser **solo un fixture de pruebas**: para producción se recomienda Hocuspocus o Y-Sweet.

## Cómo medir sin invadir la privacidad
Registrar solo: nº de escenarios ejecutados, nº superados, semillas fallidas, tiempo de integración que el propio
desarrollador reporta, errores de instalación. **Nunca** contenido de documentos.
