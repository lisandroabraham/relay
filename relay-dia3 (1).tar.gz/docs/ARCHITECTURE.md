# Arquitectura (estado: Día 2–6 parcial)

## Componentes
```
Navegador A                                   Servidor de relevo (Node, en memoria)        Navegador B
┌───────────────────────┐   WebSocket binario  ┌──────────────────────────────┐   ┌───────────────────────┐
│ React + CodeMirror 6  │◄────────────────────►│ valida origen/id/tamaño/tasa │◄─►│ (igual que A)         │
│ Y.Doc (Y.Text, Y.Map) │  protocolo y-sync    │ Room = Y.Doc por documento   │   │                       │
│ DocPersistence ──► IndexedDB (registro de actualizaciones)  │ se destruye si queda vacía │   │                       │
│ SyncSession (y-websocket, backoff, pausa)    └──────────────────────────────┘   └───────────────────────┘
```
Código: `apps/web/src/data` (persistencia, sin React), `apps/web/src/sync` (transporte),
`apps/web/src/ui` (React), `apps/server/src` (servidor).

## Flujo de una edición
1. CodeMirror → `Y.Text` (binding `y-codemirror.next`). Se genera una actualización de Yjs.
2. `DocPersistence` la encola y la escribe en IndexedDB; el estado local solo pasa a «guardado» al
   completarse la transacción. Si falla, se reintentan juntas todas las pendientes (sin huecos).
3. Si la sincronización está activada para ese documento, `SyncSession` envía la actualización por
   WebSocket. El servidor la aplica a su `Y.Doc` de sala y la retransmite a los demás clientes.
4. Los cambios remotos se aplican al `Y.Doc` local y también se guardan en IndexedDB.

## Reconexión
Al (re)conectar, cliente y servidor intercambian vectores de estado y las actualizaciones que
faltan (pasos 1 y 2 del protocolo de Yjs). Espera exponencial 100 ms → tope configurable (15 s en
la app). No se reintenta tras cierres permanentes (1009, 4400–4499). El navegador reporta
`offline/online` y la UI ofrece «Simular sin conexión». `BroadcastChannel` está desactivado a
propósito: «sin conexión» debe significar sin sincronización entre pestañas.

## Qué significa cada estado
| Estado en la UI | Significado exacto |
|---|---|
| ✓ Guardado en este dispositivo | La transacción de IndexedDB con todos los cambios locales se completó |
| ✓ Conectado · estado del servidor recibido | WebSocket abierto y se aplicó el estado que envió el servidor tras conectar. **No** confirma que el servidor haya recibido cada edición posterior |
| ✕ / ⏸ Sin conexión | Sin enlace (real o simulado). Se sigue editando; se guarda local |
| ⚠ Rechazado | El servidor cerró de forma permanente; no se reintenta |

## Qué escenarios soporta realmente
| Escenario | Soportado |
|---|---|
| Un cliente se va; otro sigue | Sí |
| Todos cierran la app | El servidor descarta la sala. El documento solo existe en los IndexedDB de los clientes |
| Reinicio del servidor | Sí, si algún cliente conserva el estado: lo repone al reconectar (probado) |
| Cliente nuevo abre un enlace | Solo recibe contenido si algún cliente conectado lo tiene en ese momento |
| Dispositivo desconectado mucho tiempo | Sí en el modelo (Yjs); sin límite de tiempo probado |
| Recuperar un documento desde un dispositivo nuevo sin otros clientes | **No** (requiere almacenamiento en servidor) |

## Límites de confianza
El servidor ve el contenido en claro (no hay cifrado de extremo a extremo). No hay autenticación:
el identificador del documento en el enlace actúa como capacidad de acceso. Ver `SECURITY.md`.
