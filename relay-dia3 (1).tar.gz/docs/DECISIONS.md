# Decisiones técnicas

## D1. Yjs como modelo colaborativo (Día 0)
- **Contexto:** MVP de 7 días con editor de texto y funcionamiento sin conexión.
- **Alternativas:** Automerge; implementación propia.
- **Motivo:** en la fecha de la decisión, `automerge-repo` tenía como tag `latest` una versión alpha
  (2.6.0-alpha.3) con un backend de sincronización nuevo, y la capa de sync era la que más cambiaba.
  Yjs es estable y tiene binding para CodeMirror 6.
- **Consecuencias:** hay que ensamblar piezas (persistencia, transporte). Revisar Automerge en la
  semana 4 si cobran importancia el cifrado de extremo a extremo y el control de acceso.

## D2. Persistencia propia en lugar de `y-indexeddb` (Día 1)
- **Contexto:** el requisito 4.2 exige no mostrar un guardado como exitoso si falló.
- **Hallazgo:** `y-indexeddb@9.0.12` escribe con `addAutoKey` sin esperar la transacción ni
  capturar errores; no puede confirmar un guardado ni reportar fallos.
- **Decisión:** capa propia (~200 líneas) que guarda un registro de actualizaciones de Yjs y
  confirma al completarse la transacción. Ante un fallo conserva las actualizaciones en memoria y
  las reintenta juntas, sin dejar huecos.
- **Consecuencias:** código propio que mantener (no es un CRDT, solo almacenamiento de
  actualizaciones). La compactación está implementada y probada con un IndexedDB simulado.

## D3. Título como registro «último escritor gana»
El título vive en el `Y.Map` «meta» del propio documento (viaja al compartir). Dos ediciones
simultáneas del título no se fusionan: gana una. El texto del documento sí es un `Y.Text` colaborativo.
La lista de documentos guarda una copia del título como caché de lectura.

## D4. Servidor propio sobre `ws` + `y-protocols` (Día 2)
- **Contexto:** el servidor de referencia (`@y/websocket-server` 0.1.5) es pre-1.0 y no valida tamaños,
  origen ni ids, requisitos de la especificación.
- **Decisión:** servidor mínimo propio (~250 líneas) que usa el protocolo estándar de Yjs y añade límites,
  validación y cierre ordenado. Cliente: `y-websocket` 3.1.0.
- **Consecuencias:** código de seguridad a mantener. Mensajes de cierre 4400–4499 = permanentes (convención del cliente).

## D5. Sincronización opt-in por documento y proxy en desarrollo (Día 2)
- Los documentos son locales por defecto; activar la sincronización pide confirmación explícita (se envía al
  servidor, sin autenticación). Evita enviar contenido privado por accidente.
- En desarrollo el navegador se conecta a `/sync` del propio Vite, que lo reenvía al servidor: sin CORS y sin
  hacer público ningún puerto en Codespaces. Verificado que el proxy conserva `Origin`.

## D6. El servidor debe devolver la presencia (bug encontrado en prueba de reposo)
`y-websocket` cierra la conexión tras 30 s sin recibir mensajes y espera el eco de sus mensajes de presencia.
Con un servidor que los ignoraba, un documento inactivo se reconectaba cada ~30 s (3 conexiones en 75 s).
Se corrigió reenviando la presencia a la sala (1 conexión en 75 s). Lección: las pruebas cortas no ven fallos de reposo.

## D7. Dos copias de Yjs en un monorepo
Los tests del servidor importan `SyncSession` desde `apps/web`. Funciona porque pnpm resuelve ambas a la
misma copia física de `yjs`. Si las versiones divergen, Yjs avisa de importación duplicada: mantenerlas iguales.

## D8. Límites por tamaño real del estado, no por caracteres (medición)
- **Hallazgo:** el estado de Yjs pesa de ~1 a ~22 bytes por carácter según el historial; borrar lo aumenta
  (`docs/BENCHMARKS.md`). Un documento de ~48.000 caracteres muy editado superaba 1 MiB.
- **Decisión:** el cliente mide el estado real (`MAX_STATE_BYTES` = 3 MiB, aviso al 70 %, solo lectura al superarlo, con
  «Crear copia compacta»); el servidor admite mensajes de 4 MiB y salas de 8 MiB, midiendo el estado real cada 64 KiB de tráfico.
  Se descartó el contador de bytes acumulados porque penalizaba salas longevas sin reflejar el tamaño real.
- **Consecuencias:** una copia compacta crea otro documento (otro id, sin sincronización): no es una operación transparente.

## D9. El límite de tasa debe ser transitorio
Un cierre 4429 (permanente según la convención de `y-websocket`) dejaba al usuario «rechazado» tras una ráfaga
legítima. Se cambió a 4529 (reintento con espera). Detectado porque un banco de pruebas con ráfagas se colgaba.

## D10. El servidor propio es un fixture de pruebas, no una ventaja
La investigación (`docs/COMPETITION.md`) muestra que Hocuspocus y Y-Sweet cubren lo que hace nuestro servidor.
Se mantiene para las pruebas de integración; no se ampliará. Ver `docs/ROADMAP.md`.
