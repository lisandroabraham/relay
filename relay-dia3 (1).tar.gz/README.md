# Relay

Aplicación de notas **local-first** (en construcción). Objetivo de la primera semana: demostrar
que se puede seguir editando sin conexión y recuperar un estado coherente al sincronizar.

## Estado actual

| Capacidad | Estado |
|---|---|
| Crear, listar, abrir y editar documentos; persistencia local con guardado **confirmado** | Implementado · probado (Vitest) |
| Sincronización entre navegadores por WebSocket (opt-in por documento) | Implementado · probado con servidor y clientes reales en `localhost` |
| Edición sin conexión, reconexión con espera progresiva, «Simular sin conexión» | Implementado · probado (lógica); interfaz **sin verificar en navegador** |
| Reinicio del servidor, mensajes duplicados/malformados/enormes, límites, orígenes | Implementado · probado |
| 150 escenarios deterministas de convergencia | Implementado · superados |
| Límites de tamaño basados en el estado real; copia compacta | Implementado · probado (datos); interfaz sin verificar en navegador |
| Mediciones (tamaño de estado, memoria, latencia, convergencia) | Hechas en entorno sintético → `docs/BENCHMARKS.md` |
| Mediciones de IndexedDB en navegador real (`#/bench`) | **Pendiente: las ejecuta el usuario** |
| Pruebas E2E con navegador real (Playwright) | **Escritas, no ejecutadas** |
| Análisis de competencia | Hecho → `docs/COMPETITION.md` (conclusión: la hipótesis original es débil; ver `docs/ROADMAP.md`) |
| Eliminar documentos · límite de tamaño de documento · autenticación · cifrado | **No implementado** |

## Requisitos
Node.js LTS y pnpm (`npm install -g pnpm`).

## Ejecutar
```bash
pnpm install
pnpm dev          # arranca servidor (:1234) y web (:5173) a la vez
pnpm typecheck
pnpm test         # pruebas unitarias de la capa de datos
pnpm build
```
Pruebas E2E (necesitan descargar un navegador la primera vez):
```bash
pnpm --filter @relay/web exec playwright install --with-deps chromium
pnpm test:e2e
```

## Limitaciones importantes
- Sin sincronización, los datos viven **solo en este navegador**. Con ella, el servidor solo guarda el
  documento en memoria mientras haya clientes conectados: si todos cierran, la única copia está en sus navegadores.
- «Conectado · estado del servidor recibido» **no** garantiza que el servidor haya recibido cada edición posterior.
- «Guardado en este dispositivo» significa: la transacción de IndexedDB se completó según el
  navegador. No garantiza que el sistema operativo haya volcado a disco.
- No hay autenticación ni cifrado: **cualquiera con el enlace de un documento sincronizado puede leerlo y editarlo**. No guardes información sensible. Ver `SECURITY.md`.

## Estructura
```
apps/web/src/data    Capa de datos (sin React): idb.ts, persistence.ts, documentStore.ts
apps/web/src/sync    Transporte: SyncSession (reconexión, pausa, estados), URL del servidor
apps/web/src/ui      Componentes React
apps/server/src      Servidor de relevo (ws + y-protocols)
apps/*/tests, e2e    Pruebas (ver TESTING.md)
docs/                ARCHITECTURE, DECISIONS, BENCHMARKS, COMPETITION, ROADMAP   (raíz: SECURITY.md, TESTING.md)
```
