# Seguridad

**Relay NO está preparado para información sensible.** No ha sido auditado.

## Datos y confianza
- Los documentos viven en IndexedDB del navegador (sin cifrar).
- Con la sincronización activada, el contenido se envía en claro al servidor de relevo y se retransmite.
  El servidor lo mantiene en memoria mientras haya clientes conectados; no lo escribe en disco ni lo registra.
- **No hay autenticación ni autorización.** Quien conozca el UUID del documento puede leerlo y
  editarlo. Un UUID v4 es difícil de adivinar, pero **no es un control de seguridad** (se filtra por
  historial, capturas, mensajes reenviados…).
- La sincronización es **opt-in por documento**; los documentos locales nunca se envían al servidor.

## Controles implementados (y probados con pruebas automáticas)
| Amenaza | Control |
|---|---|
| Orígenes web no autorizados (WebSocket cross-site) | Lista de orígenes; en producción es obligatoria y `*` está prohibido |
| Ids de documento maliciosos / path traversal | Solo `/<uuid>` exacto, normalizado a minúsculas |
| Mensajes enormes | `maxPayload` (4 MiB por defecto) → cierre 1009 (permanente para ese cliente) |
| Mensajes malformados | Validación del tipo y del cuerpo; cierre 4400, sin caída del proceso |
| Ráfagas de mensajes | Límite por conexión (200/s) → cierre 4529: **transitorio**, el cliente reintenta con espera |
| Agotamiento de recursos | Límites de conexiones totales, salas y conexiones por sala; tamaño real del estado por sala (8 MiB) |
| Conexiones muertas | Heartbeat ping/pong |
| Contenido en logs | Los logs solo contienen eventos y contadores, nunca contenido |
| Inyección en la UI | El contenido se muestra mediante CodeMirror/React como texto, nunca como HTML |

## Riesgos conocidos (no resueltos)
- Sin límite por IP ni protección real frente a denegación de servicio distribuida.
- Sin TLS propio: en producción hay que poner el servidor detrás de un proxy con **WSS**.
- La presencia (awareness) se reenvía sin interpretar; un cliente puede enviar ruido a su sala.
- Una actualización de Yjs válida pero adversarial puede ser costosa de integrar (no medido).
- Una sala que supera `MAX_ROOM_STATE_BYTES` queda inutilizable (cada cliente que envíe algo es expulsado) hasta que se vacíe y se recree: falla cerrado, pero afecta a todos sus usuarios.
- El cliente se protege con `MAX_STATE_BYTES` (3 MiB de estado real) y deja el documento en solo lectura al superarlo; el servidor lo vuelve a comprobar. El tamaño depende del historial de edición (ver `docs/BENCHMARKS.md`).
- Cifrado de extremo a extremo: **no existe**. No añadiremos criptografía casera.

## Informar de vulnerabilidades
Abre un aviso privado en la pestaña «Security» del repositorio de GitHub (o un issue sin detalles
explotables pidiendo contacto privado).
