import { describe, expect, it } from 'vitest';
import { IDBFactory } from 'fake-indexeddb';
import * as Y from 'yjs';
import { DocumentStore } from '../src/data/documentStore';
import { MAX_STATE_BYTES, WARN_STATE_BYTES, levelFor, measureDoc } from '../src/data/limits';

const fragment = (doc: Y.Doc, chars: number) => {
  // Mucho historial: inserta tres veces el texto en trozos y borra dos tercios al azar.
  const t = doc.getText('content');
  let seed = 7;
  const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
  while (t.length < chars * 3) t.insert(Math.floor(rnd() * (t.length + 1)), 'abcde');
  while (t.length > chars) {
    const p = Math.floor(rnd() * t.length);
    t.delete(p, Math.min(6, t.length - p, t.length - chars));
  }
};

describe('límites de tamaño (basados en bytes reales del estado)', () => {
  it('umbrales', () => {
    expect(levelFor(0)).toBe('ok');
    expect(levelFor(WARN_STATE_BYTES - 1)).toBe('ok');
    expect(levelFor(WARN_STATE_BYTES)).toBe('warn');
    expect(levelFor(MAX_STATE_BYTES)).toBe('over');
  });

  it('no mide documentos pequeños y mide los grandes', () => {
    const d = new Y.Doc();
    d.getText('content').insert(0, 'corto');
    expect(measureDoc(d)).toEqual({ chars: 5, stateBytes: null, level: 'ok' });
    d.getText('content').insert(0, 'x'.repeat(30_000));
    const m = measureDoc(d);
    expect(m.stateBytes).toBeGreaterThan(30_000);
    expect(m.level).toBe('ok');
  });

  it('el estado de un documento fragmentado pesa mucho más que su texto', () => {
    const d = new Y.Doc();
    fragment(d, 10_000);
    const bytes = Y.encodeStateAsUpdate(d).byteLength;
    expect(bytes / d.getText('content').length).toBeGreaterThan(10); // varias veces más que 1 B/car
  });

  it('la copia compacta conserva texto y título, reduce el estado y no hereda la sincronización', async () => {
    const factory = new IDBFactory();
    const store = await DocumentStore.open(factory);
    const id = await store.create();
    await store.setSyncEnabled(id, true);
    const doc = await store.openDocument(id);
    fragment(doc.ydoc, 6_000);
    doc.setTitle('Largo');
    const before = Y.encodeStateAsUpdate(doc.ydoc).byteLength;
    const text = doc.text.toString();
    await doc.close();

    const copyId = await store.createCompactCopy(id);
    expect(copyId).not.toBe(id);
    const copy = await store.openDocument(copyId);
    expect(copy.text.toString()).toBe(text);
    expect(copy.getTitle()).toBe('Largo');
    expect(Y.encodeStateAsUpdate(copy.ydoc).byteLength).toBeLessThan(before / 5);
    expect((await store.getRow(copyId))?.sync).toBeUndefined();
    expect((await store.getRow(id))?.sync).toBe(true); // el original no cambia
    expect((await store.list()).length).toBe(2);
  });
});
