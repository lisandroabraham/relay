import { describe, expect, it } from 'vitest';
import * as Y from 'yjs';

/**
 * Qué se comprueba aquí: CONVERGENCIA de réplicas de Yjs ante ediciones aisladas y entrega
 * desordenada/duplicada. Qué NO se comprueba: que el texto resultante coincida con la intención
 * humana (eso no es automatizable; ver los tests de caracterización de abajo).
 * Para reproducir un fallo: RELAY_SEED=<semilla> pnpm test
 */

function pair(base: string) {
  const a = new Y.Doc();
  a.clientID = 1;
  const b = new Y.Doc();
  b.clientID = 2;
  a.getText('t').insert(0, base);
  Y.applyUpdate(b, Y.encodeStateAsUpdate(a));
  return { a, b, ta: a.getText('t'), tb: b.getText('t') };
}

function merge(a: Y.Doc, b: Y.Doc): [string, string] {
  const ua = Y.encodeStateAsUpdate(a);
  const ub = Y.encodeStateAsUpdate(b);
  Y.applyUpdate(a, ub);
  Y.applyUpdate(b, ua);
  return [a.getText('t').toString(), b.getText('t').toString()];
}

describe('caracterización: qué resultado produce Yjs en ediciones concurrentes (apartado 5.3)', () => {
  it('1. zonas distintas: se conservan ambas ediciones', () => {
    const p = pair('inicio ... fin');
    p.ta.insert(0, 'A:');
    p.tb.insert(p.tb.length, ':B');
    expect(merge(p.a, p.b)).toEqual(['A:inicio ... fin:B', 'A:inicio ... fin:B']);
  });

  it('2. misma posición: se conservan ambas inserciones; el orden depende del clientID, no del reloj', () => {
    let p = pair('abc');
    p.ta.insert(1, 'XX');
    p.tb.insert(1, 'YY');
    expect(merge(p.a, p.b)).toEqual(['aXXYYbc', 'aXXYYbc']);

    p = pair('abc');
    p.a.clientID = 9; // cambiar el identificador cambia el orden, nunca el contenido
    p.ta.insert(1, 'XX');
    p.tb.insert(1, 'YY');
    const [x, y] = merge(p.a, p.b);
    expect(x).toBe(y);
    expect(x).toBe('aYYXXbc');
  });

  it('3. mismo fragmento: ambas sustituciones sobreviven y se mezclan (puede no ser lo que querían)', () => {
    const p = pair('abcd');
    p.ta.delete(1, 2);
    p.ta.insert(1, 'BC');
    p.tb.delete(1, 2);
    p.tb.insert(1, 'xy');
    // Converge, pero el resultado contiene las dos versiones: requiere revisión humana.
    expect(merge(p.a, p.b)).toEqual(['aBCxyd', 'aBCxyd']);
  });

  it('4. borrar vs insertar dentro de lo borrado: la inserción concurrente SOBREVIVE', () => {
    const p = pair('hello world');
    p.ta.delete(2, 6); // A borra "llo wo"
    p.tb.insert(5, 'ZZ'); // B inserta en medio de lo que A borra
    expect(merge(p.a, p.b)).toEqual(['heZZrld', 'heZZrld']);
  });

  it('4b. borrar todo vs editar: el borrado no elimina lo que el otro escribió sin conocerlo', () => {
    const p = pair('hola');
    p.ta.delete(0, 4);
    p.tb.insert(4, '!!');
    expect(merge(p.a, p.b)).toEqual(['!!', '!!']);
  });

  it('4c/4d. borrados idénticos o solapados no se duplican ni dejan restos', () => {
    let p = pair('abcdef');
    p.ta.delete(1, 3);
    p.tb.delete(1, 3);
    expect(merge(p.a, p.b)).toEqual(['aef', 'aef']);
    p = pair('abcdef');
    p.ta.delete(1, 3);
    p.tb.delete(2, 3);
    expect(merge(p.a, p.b)).toEqual(['af', 'af']);
  });
});

// ---------- generador determinista ----------

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface Replica {
  doc: Y.Doc;
  log: Uint8Array[];
}

function runScenario(seed: number): void {
  const rnd = mulberry32(seed);
  const int = (n: number) => Math.floor(rnd() * n);
  const word = () => Array.from({ length: 1 + int(5) }, () => 'abcxyz _\n'[int(9)]).join('');

  const nReplicas = 2 + int(3); // 2..4
  const replicas: Replica[] = Array.from({ length: nReplicas }, (_, i) => {
    const doc = new Y.Doc();
    doc.clientID = 1000 + i * 7 + int(5); // ids distintos y deterministas
    const r: Replica = { doc, log: [] };
    doc.on('update', (u: Uint8Array, origin: unknown) => {
      if (origin !== 'remote') r.log.push(u);
    });
    return r;
  });

  const deliver = (src: Replica, dst: Replica) => {
    const batch = [...src.log];
    // desorden y duplicados
    for (let i = batch.length - 1; i > 0; i--) {
      const j = int(i + 1);
      [batch[i], batch[j]] = [batch[j] as Uint8Array, batch[i] as Uint8Array];
    }
    for (const u of batch) {
      Y.applyUpdate(dst.doc, u, 'remote');
      if (rnd() < 0.3) Y.applyUpdate(dst.doc, u, 'remote');
    }
  };

  // Estado base compartido
  const first = replicas[0] as Replica;
  first.doc.getText('t').insert(0, word() + word());
  for (const r of replicas.slice(1)) deliver(first, r);

  const rounds = 1 + int(4);
  for (let round = 0; round < rounds; round++) {
    // aislamiento: cada réplica edita sola (a veces muchísimo)
    for (const r of replicas) {
      const ops = rnd() < 0.2 ? 80 : int(8);
      for (let k = 0; k < ops; k++) {
        const t = r.doc.getText('t');
        if (t.length > 0 && rnd() < 0.4) {
          const pos = int(t.length);
          t.delete(pos, 1 + int(Math.min(4, t.length - pos)));
        } else {
          t.insert(int(t.length + 1), word());
        }
      }
    }
    // red parcial: algunos pares se comunican
    for (const s of replicas) for (const d of replicas) if (s !== d && rnd() < 0.4) deliver(s, d);
  }

  // Reconexión total, en orden arbitrario
  const order = replicas.map((_, i) => i).sort(() => rnd() - 0.5);
  for (const i of order) for (const j of order) if (i !== j) deliver(replicas[i] as Replica, replicas[j] as Replica);

  // Referencia: todas las actualizaciones aplicadas en orden canónico a un documento nuevo
  const ref = new Y.Doc();
  for (const r of replicas) for (const u of r.log) Y.applyUpdate(ref, u);
  const expected = ref.getText('t').toString();

  for (const r of replicas) {
    expect(r.doc.getText('t').toString()).toBe(expected);
    expect(r.doc.store.pendingStructs).toBeNull(); // no quedan dependencias sin resolver
    expect(r.doc.store.pendingDs).toBeNull();
    expect(Y.encodeStateVector(r.doc)).toEqual(Y.encodeStateVector(ref));
  }
  // Idempotencia: reaplicar todo no cambia nada
  const before = Y.encodeStateAsUpdate(first.doc);
  for (const r of replicas) for (const u of r.log) Y.applyUpdate(first.doc, u, 'remote');
  expect(Y.encodeStateAsUpdate(first.doc)).toEqual(before);
}

describe('convergencia automatizada (escenarios deterministas con semilla)', () => {
  const only = process.env.RELAY_SEED ? [Number(process.env.RELAY_SEED)] : undefined;
  const seeds = only ?? Array.from({ length: 150 }, (_, i) => i + 1);

  it(`converge en ${seeds.length} escenarios con aislamiento, desorden y duplicados`, () => {
    for (const seed of seeds) {
      try {
        runScenario(seed);
      } catch (e) {
        throw new Error(`Falló la semilla ${seed} (reproducir con RELAY_SEED=${seed}): ${String(e)}`);
      }
    }
  }, 60_000); // 150 escenarios tardan ~10 s en un portátil; el límite por defecto (5 s) no basta
});
