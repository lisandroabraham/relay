import { describe, expect, it } from 'vitest';
import { IDBFactory } from 'fake-indexeddb';
import { runPersistenceBench } from '../src/bench';

describe('banco de medición del navegador', () => {
  it('se ejecuta de principio a fin y limpia su base temporal (los números con fake-indexeddb no valen)', async () => {
    const factory = new IDBFactory();
    const rows = await runPersistenceBench(factory, { creates: 3, writes: 5, bigChars: 2000 });
    expect(rows.length).toBeGreaterThanOrEqual(6);
    expect(rows.every((r) => r.value.length > 0)).toBe(true);
    const dbs = await factory.databases();
    expect(dbs.find((d) => d.name === 'relay-bench')).toBeUndefined();
  });
});
