import { expect, test } from '@playwright/test';

// Requiere el servidor de Relay en :1234 (lo arranca playwright.config.ts).
test('dos navegadores: editan, uno se desconecta, y convergen al volver', async ({ browser }) => {
  const ctxA = await browser.newContext();
  const ctxB = await browser.newContext(); // almacenamiento independiente = otro "dispositivo"
  const a = await ctxA.newPage();
  const b = await ctxB.newPage();
  for (const p of [a, b]) p.on('dialog', (d) => void d.accept());

  await a.goto('/');
  await a.getByRole('button', { name: 'Nuevo documento' }).click();
  await a.getByRole('button', { name: 'Activar sincronización' }).click();
  await expect(a.getByText(/Conectado · estado del servidor recibido/)).toBeVisible();
  const link = await a.getByLabel(/Enlace para compartir/).inputValue();

  await b.goto(link);
  await b.getByRole('button', { name: 'abrirlo como documento compartido' }).click();
  await expect(b.getByText(/Conectado · estado del servidor recibido/)).toBeVisible();

  await a.getByLabel('Contenido del documento').click();
  await a.keyboard.type('desde A. ');
  await expect(b.getByLabel('Contenido del documento')).toContainText('desde A.');

  // A se queda sin conexión y ambos escriben
  await a.getByLabel('Simular sin conexión').check();
  await expect(a.getByText(/Sin conexión \(simulada\)/)).toBeVisible();
  await a.keyboard.type('A-offline. ');
  await expect(a.getByText('Guardado en este dispositivo')).toBeVisible(); // el editor no depende del servidor
  await b.getByLabel('Contenido del documento').click();
  await b.keyboard.press('Control+End');
  await b.keyboard.type('B-online. ');

  await a.getByLabel('Simular sin conexión').uncheck();
  await expect(a.getByText(/Conectado · estado del servidor recibido/)).toBeVisible();
  for (const p of [a, b]) {
    await expect(p.getByLabel('Contenido del documento')).toContainText('A-offline.');
    await expect(p.getByLabel('Contenido del documento')).toContainText('B-online.');
  }
});
