import * as Y from 'yjs';

/**
 * El límite se expresa en bytes del estado codificado de Yjs, NO en caracteres: el estado puede
 * pesar de ~1 a ~22 bytes por carácter según el historial de edición (docs/BENCHMARKS.md).
 * Debe quedar por debajo de MAX_MESSAGE_BYTES del servidor (4 MiB por defecto), porque un cliente
 * nuevo recibe el estado completo en un solo mensaje.
 */
export const MAX_STATE_BYTES = 3 * 1024 * 1024;
export const WARN_STATE_BYTES = Math.floor(MAX_STATE_BYTES * 0.7);
/** Por debajo de este nº de caracteres no se mide (no puede acercarse al límite en la práctica). */
export const MEASURE_MIN_CHARS = 20_000;

export type LimitLevel = 'ok' | 'warn' | 'over';

export interface DocMeasure {
  chars: number;
  /** null si no se midió por ser un documento pequeño. */
  stateBytes: number | null;
  level: LimitLevel;
}

export function levelFor(stateBytes: number): LimitLevel {
  if (stateBytes >= MAX_STATE_BYTES) return 'over';
  if (stateBytes >= WARN_STATE_BYTES) return 'warn';
  return 'ok';
}

export function measureDoc(ydoc: Y.Doc): DocMeasure {
  const chars = ydoc.getText('content').length;
  if (chars < MEASURE_MIN_CHARS) return { chars, stateBytes: null, level: 'ok' };
  const stateBytes = Y.encodeStateAsUpdate(ydoc).byteLength;
  return { chars, stateBytes, level: levelFor(stateBytes) };
}
