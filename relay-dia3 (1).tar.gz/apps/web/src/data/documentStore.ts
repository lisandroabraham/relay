import * as Y from 'yjs';
import {
  STORE_DOCS,
  STORE_UPDATES,
  StorageError,
  openRelayDb,
  runTx,
  type DocRow,
} from './idb';
import { measureDoc, type DocMeasure } from './limits';
import { DocPersistence, readTitle, type PersistenceOptions, type SaveState } from './persistence';

export const MAX_TITLE_LENGTH = 200;

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export const isValidDocId = (id: string): boolean => UUID_RE.test(id);

export class NotFoundError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'NotFoundError';
  }
}

/** Un documento abierto. Sin dependencias de React. */
export interface OpenDocument {
  readonly id: string;
  readonly ydoc: Y.Doc;
  readonly text: Y.Text;
  readonly meta: Y.Map<unknown>;
  readonly persistence: DocPersistence;
  getTitle(): string;
  /** El título es un registro "último escritor gana", no un texto colaborativo. */
  setTitle(title: string): void;
  /** Tamaño del documento frente a los límites (mide el estado real; puede costar decenas de ms). */
  measure(): DocMeasure;
  close(): Promise<SaveState>;
}

export interface StoreOptions extends PersistenceOptions {
  /** Nombre de la base de datos (solo para mediciones/tests; por defecto "relay"). */
  dbName?: string;
}

export class DocumentStore {
  private constructor(
    private db: IDBDatabase,
    private readonly factory: IDBFactory | undefined,
    private readonly opts: StoreOptions,
  ) {}

  static async open(
    factory: IDBFactory | undefined = globalThis.indexedDB,
    opts: StoreOptions = {},
  ): Promise<DocumentStore> {
    return new DocumentStore(await openRelayDb(factory, opts.dbName), factory, opts);
  }

  close(): void {
    this.db.close();
  }

  /** Reabre la conexión (p. ej. si el navegador la cerró). */
  async reopen(): Promise<void> {
    this.db = await openRelayDb(this.factory, this.opts.dbName);
  }

  async list(): Promise<DocRow[]> {
    const rows = await runTx<DocRow[]>(this.db, [STORE_DOCS], 'readonly', (tx, set) => {
      const req = tx.objectStore(STORE_DOCS).getAll();
      req.onsuccess = () => set(req.result as DocRow[]);
    });
    return rows.sort((a, b) => b.updatedAt - a.updatedAt);
  }

  async create(): Promise<string> {
    const id = crypto.randomUUID();
    const now = Date.now();
    await runTx(this.db, [STORE_DOCS], 'readwrite', (tx) => {
      tx.objectStore(STORE_DOCS).add({
        id,
        createdAt: now,
        updatedAt: now,
        title: '',
      } satisfies DocRow);
    });
    return id;
  }

  /**
   * Crea un documento nuevo con el mismo título y texto pero sin historial de edición (estado
   * mínimo, ~1 byte/carácter). Es la salida cuando un documento queda demasiado fragmentado.
   * El original no se modifica y la copia NO hereda la sincronización (es otro documento).
   */
  async createCompactCopy(id: string): Promise<string> {
    const src = await this.openDocument(id);
    const text = src.text.toString();
    const title = src.getTitle();
    await src.close();
    const newId = await this.create();
    const copy = await this.openDocument(newId);
    copy.text.insert(0, text);
    if (title) copy.setTitle(title);
    const state = await copy.close();
    if (state.kind !== 'saved') {
      throw new StorageError('No se pudo guardar la copia: ' + (state.kind === 'error' ? state.message : state.kind));
    }
    return newId;
  }

  async getRow(id: string): Promise<DocRow | undefined> {
    return runTx<DocRow | undefined>(this.db, [STORE_DOCS], 'readonly', (tx, set) => {
      const req = tx.objectStore(STORE_DOCS).get(id);
      req.onsuccess = () => set(req.result as DocRow | undefined);
    });
  }

  /** Crea localmente un documento con un id recibido (enlace compartido), con sincronización activada. */
  async adopt(id: string): Promise<void> {
    if (!isValidDocId(id)) throw new NotFoundError('Identificador de documento no válido.');
    const now = Date.now();
    await runTx(this.db, [STORE_DOCS], 'readwrite', (tx) => {
      const docs = tx.objectStore(STORE_DOCS);
      const get = docs.get(id);
      get.onsuccess = () => {
        if (!get.result) {
          docs.add({ id, createdAt: now, updatedAt: now, title: '', sync: true } satisfies DocRow);
        } else {
          docs.put({ ...(get.result as DocRow), sync: true });
        }
      };
    });
  }

  async setSyncEnabled(id: string, enabled: boolean): Promise<void> {
    await runTx(this.db, [STORE_DOCS], 'readwrite', (tx) => {
      const docs = tx.objectStore(STORE_DOCS);
      const get = docs.get(id);
      get.onsuccess = () => {
        const row = get.result as DocRow | undefined;
        if (!row) throw new NotFoundError('El documento no existe.');
        docs.put({ ...row, sync: enabled });
      };
    });
  }

  async openDocument(id: string): Promise<OpenDocument> {
    if (!isValidDocId(id)) throw new NotFoundError('Identificador de documento no válido.');
    const row = await runTx<DocRow | undefined>(this.db, [STORE_DOCS], 'readonly', (tx, set) => {
      const req = tx.objectStore(STORE_DOCS).get(id);
      req.onsuccess = () => set(req.result as DocRow | undefined);
    });
    if (!row) throw new NotFoundError('Este documento no existe en este navegador.');

    const ydoc = new Y.Doc({ guid: id });
    const persistence = new DocPersistence(() => this.db, id, ydoc, this.opts);
    try {
      await persistence.load();
    } catch (e) {
      ydoc.destroy();
      throw e;
    }
    const meta = ydoc.getMap<unknown>('meta');
    return {
      id,
      ydoc,
      text: ydoc.getText('content'),
      meta,
      persistence,
      getTitle: () => readTitle(ydoc),
      setTitle: (title) => meta.set('title', title.slice(0, MAX_TITLE_LENGTH)),
      measure: () => measureDoc(ydoc),
      close: async () => {
        const s = await persistence.close();
        ydoc.destroy();
        return s;
      },
    };
  }

  /** Diagnóstico/tests: cuántos registros de actualización hay guardados. */
  countStoredUpdates(id: string): Promise<number> {
    return runTx<number>(this.db, [STORE_UPDATES], 'readonly', (tx, set) => {
      const req = tx.objectStore(STORE_UPDATES).index('byDoc').count(id);
      req.onsuccess = () => set(req.result);
    });
  }
}

export { StorageError };
