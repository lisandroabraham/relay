/**
 * URL base del servidor de sincronización.
 * - Si existe VITE_SYNC_URL (ws:// o wss://), se usa tal cual.
 * - Si no, se usa el mismo origen de la página bajo /sync (Vite lo reenvía al servidor en desarrollo).
 *   Esto evita CORS y no obliga a hacer público un puerto en GitHub Codespaces.
 */
export function getSyncUrl(
  loc: Pick<Location, 'protocol' | 'host'> = window.location,
  configured: string | undefined = import.meta.env.VITE_SYNC_URL as string | undefined,
): string {
  if (configured) return configured.replace(/\/+$/, '');
  const scheme = loc.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${scheme}//${loc.host}/sync`;
}
