import type * as Y from 'yjs';
import { WebsocketProvider } from 'y-websocket';

/**
 * Estado del enlace con el servidor (no del documento):
 * - connecting: intentando conectar (incluye reintentos con espera progresiva)
 * - connected:  WebSocket abierto
 * - offline:    sin enlace; se reintentará solo (o el navegador reporta que no hay red)
 * - paused:     el usuario simuló la desconexión; no se reintenta
 * - rejected:   el servidor cerró de forma permanente (p. ej. mensaje demasiado grande); no se reintenta
 */
export type LinkState = 'connecting' | 'connected' | 'offline' | 'paused' | 'rejected';

export interface SyncState {
  link: LinkState;
  /**
   * true cuando, tras conectar, el servidor nos envió su estado y lo aplicamos.
   * NO confirma que el servidor haya recibido cada edición nuestra posterior.
   */
  serverStateReceived: boolean;
  closeCode?: number;
}

export interface SyncSessionOptions {
  maxBackoffMs?: number;
  WebSocketImpl?: typeof WebSocket;
}

/** Cierres tras los cuales reintentar no sirve: payload demasiado grande (1009) o 4400-4499. */
export function isPermanentClose(code: number): boolean {
  return code === 1009 || (code >= 4400 && code < 4500);
}

export class SyncSession {
  private readonly provider: WebsocketProvider;
  private readonly listeners = new Set<(s: SyncState) => void>();
  private paused = false;
  private browserOffline = false;
  private permanentCode: number | undefined;
  private state: SyncState = { link: 'connecting', serverStateReceived: false };
  private destroyed = false;

  constructor(serverUrl: string, docId: string, ydoc: Y.Doc, opts: SyncSessionOptions = {}) {
    this.provider = new WebsocketProvider(serverUrl, docId, ydoc, {
      connect: false,
      // Sin BroadcastChannel: "sin conexión" debe significar sin sincronización entre pestañas también.
      disableBc: true,
      maxBackoffTime: opts.maxBackoffMs ?? 15_000,
      shouldReconnect: (e) => !isPermanentClose(e.code),
      ...(opts.WebSocketImpl ? { WebSocketPolyfill: opts.WebSocketImpl } : {}),
    });
    this.provider.on('status', () => this.recompute());
    this.provider.on('sync', () => this.recompute());
    this.provider.on('closed', (info: { code: number }) => {
      this.permanentCode = info.code;
      this.recompute();
    });
    if (typeof window !== 'undefined') {
      window.addEventListener('offline', this.onOffline);
      window.addEventListener('online', this.onOnline);
      this.browserOffline = typeof navigator !== 'undefined' && navigator.onLine === false;
    }
  }

  private readonly onOffline = (): void => {
    this.browserOffline = true;
    this.provider.disconnect();
    this.recompute();
  };

  private readonly onOnline = (): void => {
    this.browserOffline = false;
    this.resume();
  };

  getState(): SyncState {
    return this.state;
  }

  subscribe(cb: (s: SyncState) => void): () => void {
    this.listeners.add(cb);
    cb(this.state);
    return () => this.listeners.delete(cb);
  }

  start(): void {
    this.resume();
  }

  /** Simula (o levanta) una desconexión. Las ediciones locales siguen funcionando y guardándose. */
  setPaused(paused: boolean): void {
    this.paused = paused;
    if (paused) this.provider.disconnect();
    else this.resume();
    this.recompute();
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    if (typeof window !== 'undefined') {
      window.removeEventListener('offline', this.onOffline);
      window.removeEventListener('online', this.onOnline);
    }
    this.listeners.clear();
    this.provider.destroy();
  }

  private resume(): void {
    if (this.destroyed || this.paused || this.browserOffline) return;
    this.permanentCode = undefined;
    this.provider.connect();
    this.recompute();
  }

  private recompute(): void {
    if (this.destroyed) return;
    let link: LinkState;
    if (this.paused) link = 'paused';
    else if (this.permanentCode !== undefined) link = 'rejected';
    else if (this.browserOffline) link = 'offline';
    else if (this.provider.wsconnected) link = 'connected';
    else if (this.provider.wsconnecting) link = 'connecting';
    else link = 'offline';
    const next: SyncState = {
      link,
      serverStateReceived: link === 'connected' && this.provider.synced,
      ...(this.permanentCode !== undefined ? { closeCode: this.permanentCode } : {}),
    };
    if (
      next.link === this.state.link &&
      next.serverStateReceived === this.state.serverStateReceived &&
      next.closeCode === this.state.closeCode
    ) {
      return;
    }
    this.state = next;
    for (const cb of this.listeners) cb(next);
  }
}
