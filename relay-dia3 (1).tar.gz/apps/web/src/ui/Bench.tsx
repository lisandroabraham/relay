import { useState } from 'react';
import { runPersistenceBench, type BenchRow } from '../bench';
import { describeError } from '../data/idb';

export function Bench() {
  const [rows, setRows] = useState<BenchRow[] | null>(null);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const nav = navigator as Navigator & { deviceMemory?: number };

  const run = async () => {
    setRunning(true);
    setError(null);
    try {
      setRows(await runPersistenceBench());
    } catch (e) {
      setError(describeError(e));
    } finally {
      setRunning(false);
    }
  };
  const nav0 = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming | undefined;

  return (
    <main className="page">
      <a href="#/">← Documentos</a>
      <h1>Medición de rendimiento</h1>
      <p className="muted">
        Usa una base de datos temporal («relay-bench») que se borra al terminar. No toca tus documentos.
        Los números dependen de tu navegador y dispositivo: anota las condiciones al compartirlos.
      </p>
      <button type="button" className="primary" onClick={() => void run()} disabled={running}>
        {running ? 'Midiendo…' : 'Ejecutar medición'}
      </button>
      {error && <p role="alert" className="banner banner-error">⚠ {error}</p>}
      {rows && (
        <table className="bench">
          <tbody>
            {rows.map((r) => (
              <tr key={r.label}>
                <th scope="row">{r.label}</th>
                <td>{r.value}</td>
              </tr>
            ))}
            {nav0 && (
              <tr>
                <th scope="row">Carga de la página (DOMContentLoaded)</th>
                <td>{nav0.domContentLoadedEventEnd.toFixed(0)} ms desde el inicio de la navegación</td>
              </tr>
            )}
          </tbody>
        </table>
      )}
      <p className="muted">
        Condiciones: {nav.userAgent} · {nav.hardwareConcurrency} núcleos
        {nav.deviceMemory ? ` · ~${nav.deviceMemory} GB RAM` : ''} · {new Date().toLocaleString()}
      </p>
    </main>
  );
}
