import { useEffect, useRef, useState } from 'react';
import { Compartment, EditorState } from '@codemirror/state';
import { EditorView, drawSelection, keymap } from '@codemirror/view';
import { defaultKeymap } from '@codemirror/commands';
import { yCollab, yUndoManagerKeymap } from 'y-codemirror.next';
import {
  MAX_TITLE_LENGTH,
  NotFoundError,
  isValidDocId,
  type DocumentStore,
  type OpenDocument,
} from '../data/documentStore';
import { describeError } from '../data/idb';
import type { DocMeasure } from '../data/limits';
import type { SaveState } from '../data/persistence';
import { SyncSession, type SyncState } from '../sync/syncSession';
import { getSyncUrl } from '../sync/syncUrl';
import { MAX_STATE_BYTES } from '../data/limits';
import { SaveBadge } from './SaveBadge';
import { SyncBadge } from './SyncBadge';

const kib = (n: number | null) => (n === null ? '?' : `${(n / 1024).toFixed(0)} KiB`);
const lockExt = (locked: boolean) => [EditorState.readOnly.of(locked), EditorView.editable.of(!locked)];
const lock = new Compartment();

export function Editor({ store, id }: { store: DocumentStore; id: string }) {
  const host = useRef<HTMLDivElement>(null);
  const docRef = useRef<OpenDocument | null>(null);
  const [doc, setDoc] = useState<OpenDocument | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [save, setSave] = useState<SaveState>({ kind: 'loading' });
  const [title, setTitle] = useState('');
  const [attempt, setAttempt] = useState(0);
  const [notFound, setNotFound] = useState(false);
  const [syncEnabled, setSyncEnabled] = useState(false);
  const [syncState, setSyncState] = useState<SyncState | null>(null);
  const [simulateOffline, setSimulateOffline] = useState(false);
  const sessionRef = useRef<SyncSession | null>(null);
  const viewRef = useRef<EditorView | null>(null);
  const [limit, setLimit] = useState<DocMeasure | null>(null);
  const limitRef = useRef<DocMeasure | null>(null);
  limitRef.current = limit;
  const shareLink = `${location.origin}${location.pathname}#/doc/${id}`;

  // Abrir / cerrar el documento (tolerante a StrictMode y a cambios rápidos de ruta).
  useEffect(() => {
    let cancelled = false;
    let opened: OpenDocument | null = null;
    setLoadError(null);
    setNotFound(false);
    (async () => {
      const d = await store.openDocument(id);
      const row = await store.getRow(id);
      if (cancelled) {
        void d.close();
        return;
      }
      opened = d;
      docRef.current = d;
      setSyncEnabled(row?.sync === true);
      setDoc(d);
    })().catch((e: unknown) => {
      if (cancelled) return;
      setNotFound(e instanceof NotFoundError && isValidDocId(id));
      setLoadError(describeError(e));
    });
    return () => {
      cancelled = true;
      docRef.current = null;
      setDoc(null);
      if (opened) void opened.close();
    };
  }, [store, id, attempt]);

  // Sesión de sincronización (solo si el usuario la activó para este documento).
  useEffect(() => {
    if (!doc || !syncEnabled) return;
    const session = new SyncSession(getSyncUrl(), doc.id, doc.ydoc);
    sessionRef.current = session;
    const unsub = session.subscribe(setSyncState);
    session.start();
    return () => {
      unsub();
      session.destroy();
      sessionRef.current = null;
      setSyncState(null);
      setSimulateOffline(false);
    };
  }, [doc, syncEnabled]);

  // Editor CodeMirror enlazado al Y.Text.
  useEffect(() => {
    if (!doc || !host.current) return;
    const view = new EditorView({
      parent: host.current,
      state: EditorState.create({
        doc: doc.text.toString(),
        extensions: [
          drawSelection(),
          EditorView.lineWrapping,
          EditorView.contentAttributes.of({ 'aria-label': 'Contenido del documento' }),
          keymap.of([...yUndoManagerKeymap, ...defaultKeymap]),
          yCollab(doc.text, null),
          lock.of(lockExt(limitRef.current?.level === 'over')),
        ],
      }),
    });
    viewRef.current = view;
    return () => {
      viewRef.current = null;
      view.destroy();
    };
  }, [doc]);

  // Límite de tamaño: mide el estado real (no los caracteres), sin bloquear cada pulsación.
  useEffect(() => {
    if (!doc) return;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const check = () => setLimit(doc.measure());
    const onUpdate = () => {
      clearTimeout(timer);
      timer = setTimeout(check, 1500);
    };
    check();
    doc.ydoc.on('update', onUpdate);
    return () => {
      clearTimeout(timer);
      doc.ydoc.off('update', onUpdate);
    };
  }, [doc]);

  useEffect(() => {
    viewRef.current?.dispatch({ effects: lock.reconfigure(lockExt(limit?.level === 'over')) });
  }, [limit?.level]);

  // Título (Y.Map "meta") y estado de guardado.
  useEffect(() => {
    if (!doc) return;
    const sync = () => setTitle(doc.getTitle());
    sync();
    doc.meta.observe(sync);
    const unsub = doc.persistence.subscribe(setSave);
    return () => {
      doc.meta.unobserve(sync);
      unsub();
    };
  }, [doc]);

  // Avisar si se intenta cerrar con cambios sin confirmar en disco.
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      const s = docRef.current?.persistence.getState();
      if (s && s.kind !== 'saved') e.preventDefault();
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, []);

  const toggleSync = async () => {
    if (!doc) return;
    if (!syncEnabled) {
      const ok = window.confirm(
        'Al activar la sincronización, el contenido de este documento se enviará al servidor de Relay ' +
          'y cualquiera que tenga el enlace podrá leerlo y editarlo (no hay autenticación). ' +
          'No lo uses para información sensible. ¿Continuar?',
      );
      if (!ok) return;
    }
    try {
      await store.setSyncEnabled(doc.id, !syncEnabled);
      setSyncEnabled(!syncEnabled);
    } catch (e) {
      setLoadError(describeError(e));
    }
  };

  const compactCopy = async () => {
    if (!doc) return;
    try {
      location.hash = `#/doc/${await store.createCompactCopy(doc.id)}`;
    } catch (e) {
      setLoadError(describeError(e));
    }
  };

  const adoptShared = async () => {
    const ok = window.confirm(
      'Vas a abrir un documento compartido: se creará una copia local y se sincronizará con el ' +
        'servidor. Cualquiera con el enlace puede editarlo. ¿Continuar?',
    );
    if (!ok) return;
    try {
      await store.adopt(id);
      setAttempt((n) => n + 1);
    } catch (e) {
      setLoadError(describeError(e));
    }
  };

  if (loadError && !doc) {
    return (
      <main className="page">
        <p role="alert" className="banner banner-error">
          ⚠ {loadError}
        </p>
        {notFound && (
          <p>
            Si alguien te envió este enlace, puedes{' '}
            <button type="button" onClick={() => void adoptShared()}>
              abrirlo como documento compartido
            </button>
            .
          </p>
        )}
        <a href="#/">← Volver a la lista</a>
      </main>
    );
  }

  return (
    <main className="page">
      <a href="#/">← Documentos</a>
      <label htmlFor="title" className="label">
        Título
      </label>
      <input
        id="title"
        className="title-input"
        value={title}
        maxLength={MAX_TITLE_LENGTH}
        disabled={!doc}
        placeholder="Sin título"
        onChange={(e) => doc?.setTitle(e.target.value)}
      />
      <SaveBadge state={save} onRetry={() => void doc?.persistence.retry()} />
      <SyncBadge state={syncEnabled ? syncState : null} />
      <div className="row">
        <button type="button" onClick={() => void toggleSync()} disabled={!doc}>
          {syncEnabled ? 'Desactivar sincronización' : 'Activar sincronización'}
        </button>
        {syncEnabled && (
          <label>
            <input
              type="checkbox"
              checked={simulateOffline}
              onChange={(e) => {
                setSimulateOffline(e.target.checked);
                sessionRef.current?.setPaused(e.target.checked);
              }}
            />{' '}
            Simular sin conexión
          </label>
        )}
      </div>
      {syncEnabled && (
        <div className="share">
          <label htmlFor="share-link" className="label">
            Enlace para compartir (cualquiera con el enlace puede leer y editar)
          </label>
          <input id="share-link" className="title-input" readOnly value={shareLink} onFocus={(e) => e.target.select()} />
        </div>
      )}
      {limit?.level === 'warn' && (
        <p role="status" className="banner">
          El documento se acerca al límite de tamaño ({kib(limit.stateBytes)} de {kib(MAX_STATE_BYTES)}).
          Considera dividirlo en varios documentos.
        </p>
      )}
      {limit?.level === 'over' && (
        <p role="alert" className="banner banner-error">
          ⚠ Este documento alcanzó el límite de tamaño ({kib(limit.stateBytes)}) y ya no se puede editar. El
          tamaño depende del historial de edición, no solo del texto, y borrar no lo reduce.{' '}
          <button type="button" onClick={() => void compactCopy()}>
            Crear copia compacta
          </button>
        </p>
      )}
      <div ref={host} className="editor" />
    </main>
  );
}
