import type { SyncState } from '../sync/syncSession';

export function SyncBadge({ state }: { state: SyncState | null }) {
  if (!state) {
    return (
      <p role="status" className="badge">
        ○ Sincronización desactivada: este documento solo existe en este navegador
      </p>
    );
  }
  switch (state.link) {
    case 'connecting':
      return <p role="status" className="badge">… Conectando con el servidor</p>;
    case 'connected':
      return state.serverStateReceived ? (
        <p role="status" className="badge badge-ok">
          ✓ Conectado · estado del servidor recibido
        </p>
      ) : (
        <p role="status" className="badge">… Conectado · intercambiando cambios</p>
      );
    case 'paused':
      return (
        <p role="status" className="badge badge-warn">
          ⏸ Sin conexión (simulada) · sigues editando; los cambios se guardan en este dispositivo
        </p>
      );
    case 'offline':
      return (
        <p role="status" className="badge badge-warn">
          ✕ Sin conexión con el servidor · sigues editando; se reintentará solo
        </p>
      );
    case 'rejected':
      return (
        <p role="alert" className="badge badge-error">
          ⚠ El servidor rechazó la conexión (código {state.closeCode}). No se reintentará. Tus cambios
          siguen guardados en este dispositivo.
        </p>
      );
  }
}
