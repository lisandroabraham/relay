import * as Y from 'yjs';
import { DocumentStore } from './data/documentStore';

export interface BenchRow {
  label: string;
  value: string;
}

const pct = (xs: number[], p: number): number => {
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.floor((p / 100) * s.length))] ?? 0;
};
const ms = (n: number) => `${n.toFixed(2)} ms`;
const summary = (xs: number[]) => `p50 ${ms(pct(xs, 50))} · p95 ${ms(pct(xs, 95))} · máx ${ms(Math.max(...xs))}`;

/**
 * Mide persistencia local. Usa una base de datos temporal ("relay-bench") que se borra al terminar:
 * no toca los documentos del usuario. Los resultados dependen del navegador y del dispositivo.
 */
export async function runPersistenceBench(
  factory: IDBFactory = indexedDB,
  opts: { creates?: number; writes?: number; bigChars?: number } = {},
): Promise<BenchRow[]> {
  const { creates = 30, writes = 300, bigChars = 100_000 } = opts;
  const dbName = 'relay-bench';
  const rows: BenchRow[] = [];
  const store = await DocumentStore.open(factory, { dbName });
  try {
    // 1. Crear documentos
    const t: number[] = [];
    for (let i = 0; i < creates; i++) {
      const t0 = performance.now();
      await store.create();
      t.push(performance.now() - t0);
    }
    rows.push({ label: `Crear documento (${creates} muestras)`, value: summary(t) });

    // 2. Confirmar un guardado tras una edición pequeña
    const id = await store.create();
    const doc = await store.openDocument(id);
    const w: number[] = [];
    for (let i = 0; i < writes; i++) {
      const t0 = performance.now();
      doc.text.insert(doc.text.length, 'x');
      await doc.persistence.flush();
      w.push(performance.now() - t0);
    }
    rows.push({ label: `Guardado confirmado por edición (${writes} muestras, una transacción cada una)`, value: summary(w) });
    await doc.close();

    // 3. Reabrir un documento con muchos registros
    const t1 = performance.now();
    const again = await store.openDocument(id);
    rows.push({ label: `Reabrir documento con ${writes} registros`, value: ms(performance.now() - t1) });
    await again.close();

    // 4. Documento grande de golpe
    const bigId = await store.create();
    const big = await store.openDocument(bigId);
    const t2 = performance.now();
    big.text.insert(0, 'abcdefghij'.repeat(bigChars / 10));
    await big.persistence.flush();
    rows.push({ label: `Guardar un pegado de ${bigChars.toLocaleString('es')} caracteres`, value: ms(performance.now() - t2) });
    await big.close();
    const t3 = performance.now();
    const bigAgain = await store.openDocument(bigId);
    rows.push({ label: `Reabrir ese documento de ${bigChars.toLocaleString('es')} caracteres`, value: ms(performance.now() - t3) });
    const t4 = performance.now();
    const bytes = Y.encodeStateAsUpdate(bigAgain.ydoc).byteLength;
    rows.push({ label: 'Codificar su estado completo', value: `${ms(performance.now() - t4)} (${(bytes / 1024).toFixed(0)} KiB)` });
    await bigAgain.close();

    // 5. Listar
    const t5 = performance.now();
    const list = await store.list();
    rows.push({ label: `Listar ${list.length} documentos`, value: ms(performance.now() - t5) });
  } finally {
    store.close();
    await new Promise<void>((resolve) => {
      const req = factory.deleteDatabase(dbName);
      req.onsuccess = req.onerror = req.onblocked = () => resolve();
    });
  }
  return rows;
}
