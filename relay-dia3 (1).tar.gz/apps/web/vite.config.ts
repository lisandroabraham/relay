import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    // Necesario para abrir la app desde la URL reenviada de GitHub Codespaces.
    host: true,
    allowedHosts: ['.app.github.dev'],
    // En desarrollo, /sync se reenvía (WebSocket incluido) al servidor de Relay.
    proxy: {
      '/sync': {
        target: 'ws://127.0.0.1:1234',
        ws: true,
        rewrite: (path: string) => path.replace(/^\/sync/, ''),
      },
    },
  },
  test: {
    environment: 'node',
    include: ['tests/**/*.test.ts'],
  },
});
