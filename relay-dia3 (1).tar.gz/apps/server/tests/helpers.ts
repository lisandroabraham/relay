import * as Y from 'yjs';
import * as encoding from 'lib0/encoding';
import * as syncProtocol from 'y-protocols/sync';
import { WebSocket } from 'ws';
import { loadConfig, type ServerConfig } from '../src/config';
import { createRelayServer, type RelayServer } from '../src/server';
import { SyncSession, type SyncState } from '../../web/src/sync/syncSession';

export function testConfig(overrides: Partial<ServerConfig> = {}): ServerConfig {
  return { ...loadConfig({}), port: 0, quiet: true, heartbeatMs: 60_000, ...overrides };
}

export async function startServer(
  overrides: Partial<ServerConfig> = {},
): Promise<{ server: RelayServer; port: number; url: string }> {
  const server = createRelayServer(testConfig(overrides));
  const port = await server.listen();
  return { server, port, url: `ws://127.0.0.1:${port}` };
}

export async function waitFor(
  cond: () => boolean,
  what: string,
  timeoutMs = 8000,
): Promise<void> {
  const start = Date.now();
  while (!cond()) {
    if (Date.now() - start > timeoutMs) throw new Error(`Timeout esperando: ${what}`);
    await new Promise((r) => setTimeout(r, 15));
  }
}

export interface Client {
  doc: Y.Doc;
  session: SyncSession;
  text: () => string;
  state: () => SyncState;
  stop: () => void;
}

export function makeClient(url: string, docId: string, maxBackoffMs = 250): Client {
  const doc = new Y.Doc();
  const session = new SyncSession(url, docId, doc, { maxBackoffMs });
  let state = session.getState();
  session.subscribe((s) => {
    state = s;
  });
  session.start();
  return {
    doc,
    session,
    text: () => doc.getText('content').toString(),
    state: () => state,
    stop: () => session.destroy(),
  };
}

export const whenSynced = (c: Client) =>
  waitFor(() => c.state().link === 'connected' && c.state().serverStateReceived, 'cliente sincronizado');

export function updateMessage(update: Uint8Array): Uint8Array {
  const e = encoding.createEncoder();
  encoding.writeVarUint(e, 0);
  syncProtocol.writeUpdate(e, update);
  return encoding.toUint8Array(e);
}

export function rawSocket(url: string, docId: string, headers: Record<string, string> = {}) {
  const ws = new WebSocket(`${url}/${docId}`, { headers });
  const closed = new Promise<{ code: number }>((resolve) => ws.on('close', (code) => resolve({ code })));
  const opened = new Promise<void>((resolve, reject) => {
    ws.once('open', () => resolve());
    ws.once('error', reject);
    ws.once('unexpected-response', (_req, res) => reject(Object.assign(new Error('rechazado'), { status: res.statusCode })));
  });
  return { ws, closed, opened };
}

export const newId = () => crypto.randomUUID();
