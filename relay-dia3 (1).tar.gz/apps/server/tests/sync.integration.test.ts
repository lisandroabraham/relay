import { afterEach, describe, expect, it } from 'vitest';
import * as Y from 'yjs';
import {
  makeClient,
  newId,
  rawSocket,
  startServer,
  updateMessage,
  waitFor,
  whenSynced,
  type Client,
} from './helpers';
import type { RelayServer } from '../src/server';

const clients: Client[] = [];
const servers: RelayServer[] = [];
const track = (c: Client) => (clients.push(c), c);

afterEach(async () => {
  for (const c of clients.splice(0)) c.stop();
  for (const s of servers.splice(0)) await s.close();
});

async function boot(overrides = {}) {
  const s = await startServer(overrides);
  servers.push(s.server);
  return s;
}

describe('sincronización entre dos clientes', () => {
  it('converge en tiempo real en ambos sentidos', async () => {
    const { url } = await boot();
    const id = newId();
    const a = track(makeClient(url, id));
    const b = track(makeClient(url, id));
    await Promise.all([whenSynced(a), whenSynced(b)]);

    a.doc.getText('content').insert(0, 'hola');
    await waitFor(() => b.text() === 'hola', 'B recibe "hola"');
    b.doc.getText('content').insert(4, ' mundo');
    await waitFor(() => a.text() === 'hola mundo', 'A recibe " mundo"');
  });

  it('un cliente que llega tarde recibe el estado de la sala', async () => {
    const { url } = await boot();
    const id = newId();
    const a = track(makeClient(url, id));
    await whenSynced(a);
    a.doc.getText('content').insert(0, 'previo');
    const late = track(makeClient(url, id));
    await waitFor(() => late.text() === 'previo', 'cliente tardío recibe estado');
  });

  it('documentos distintos no se mezclan', async () => {
    const { url } = await boot();
    const a = track(makeClient(url, newId()));
    const b = track(makeClient(url, newId()));
    await Promise.all([whenSynced(a), whenSynced(b)]);
    a.doc.getText('content').insert(0, 'solo A');
    await new Promise((r) => setTimeout(r, 200));
    expect(b.text()).toBe('');
  });
});

describe('desconexiones y reconexión', () => {
  it('ambos editan sin conexión; al volver, en orden distinto, convergen sin perder ediciones', async () => {
    const { url } = await boot();
    const id = newId();
    const a = track(makeClient(url, id));
    const b = track(makeClient(url, id));
    await Promise.all([whenSynced(a), whenSynced(b)]);
    a.doc.getText('content').insert(0, 'base');
    await waitFor(() => b.text() === 'base', 'estado base compartido');

    a.session.setPaused(true);
    b.session.setPaused(true);
    expect(a.state().link).toBe('paused');
    // sin conexión el editor sigue funcionando
    a.doc.getText('content').insert(0, 'AAA-');
    b.doc.getText('content').insert(b.text().length, '-BBB');
    for (let i = 0; i < 50; i++) a.doc.getText('content').insert(a.text().length, String(i % 10));
    await new Promise((r) => setTimeout(r, 150));
    expect(a.text()).not.toBe(b.text()); // divergen mientras están aisladas

    b.session.setPaused(false); // vuelve primero B
    await whenSynced(b);
    a.session.setPaused(false);
    await whenSynced(a);
    await waitFor(() => a.text() === b.text(), 'convergencia tras reconexión');
    expect(a.text()).toContain('AAA-base');
    expect(a.text()).toContain('-BBB');
    expect(a.text()).toContain('01234567890123456789');
  });

  it('sobrevive al reinicio del servidor: los clientes reponen el estado desde sus copias', async () => {
    const first = await boot();
    const id = newId();
    const a = track(makeClient(first.url, id));
    const b = track(makeClient(first.url, id));
    await Promise.all([whenSynced(a), whenSynced(b)]);
    a.doc.getText('content').insert(0, 'antes');
    await waitFor(() => b.text() === 'antes', 'estado previo');

    await first.server.close();
    servers.splice(servers.indexOf(first.server), 1);
    await waitFor(() => a.state().link !== 'connected' && b.state().link !== 'connected', 'detectan caída');

    a.doc.getText('content').insert(0, 'A:');
    b.doc.getText('content').insert(b.text().length, ':B');

    const second = await boot({ port: first.port }); // servidor nuevo, sin memoria del anterior
    expect(second.port).toBe(first.port);
    await waitFor(() => a.state().serverStateReceived && b.state().serverStateReceived, 'reconectan', 10_000);
    await waitFor(() => a.text() === b.text(), 'convergen tras reinicio');
    expect(a.text()).toBe(b.text());
    expect(a.text()).toContain('A:antes');
    expect(a.text()).toContain(':B');
  });

  it('cuando todos salen, el servidor no conserva el documento (el estado vive en los clientes)', async () => {
    const { url, server } = await boot();
    const id = newId();
    const a = track(makeClient(url, id));
    await whenSynced(a);
    a.doc.getText('content').insert(0, 'efímero');
    await new Promise((r) => setTimeout(r, 100));
    a.stop();
    await waitFor(() => server.stats().rooms === 0, 'sala destruida');

    const fresh = track(makeClient(url, id));
    await whenSynced(fresh);
    expect(fresh.text()).toBe(''); // limitación documentada
  });

  it('no reintenta tras un cierre permanente del servidor (4413) y lo refleja como "rejected"', async () => {
    const { url, server } = await boot({ maxRoomStateBytes: 200, stateCheckIntervalBytes: 0 });
    const a = track(makeClient(url, newId()));
    await whenSynced(a);
    a.doc.getText('content').insert(0, 'x'.repeat(500));
    await waitFor(() => a.state().link === 'rejected', 'estado rejected');
    expect(a.state().closeCode).toBe(4413);
    const conns = server.stats().connections;
    await new Promise((r) => setTimeout(r, 800)); // más que varios backoffs
    expect(server.stats().connections).toBe(conns); // no hubo reconexión
    expect(a.state().link).toBe('rejected');
    // las ediciones locales siguen funcionando
    a.doc.getText('content').insert(0, 'local');
    expect(a.text().startsWith('local')).toBe(true);
  });
});

describe('robustez y seguridad del servidor', () => {
  it('aplicar dos veces la misma actualización no altera el estado', async () => {
    const { url } = await boot();
    const id = newId();
    const src = new Y.Doc();
    src.getText('content').insert(0, 'una vez');
    const msg = updateMessage(Y.encodeStateAsUpdate(src));
    const raw = rawSocket(url, id);
    await raw.opened;
    raw.ws.send(msg);
    raw.ws.send(msg);
    await new Promise((r) => setTimeout(r, 150));
    const reader = track(makeClient(url, id));
    await waitFor(() => reader.text() === 'una vez', 'lector recibe el texto una sola vez');
    raw.ws.close();
  });

  it('un mensaje mayor que el límite cierra esa conexión (1009) y el servidor sigue', async () => {
    const { url, server } = await boot({ maxMessageBytes: 1024 });
    const id = newId();
    const ok = track(makeClient(url, id));
    await whenSynced(ok);
    const raw = rawSocket(url, newId());
    await raw.opened;
    raw.ws.send(new Uint8Array(4096));
    expect((await raw.closed).code).toBe(1009);
    ok.doc.getText('content').insert(0, 'sigue vivo');
    const other = track(makeClient(url, id));
    await waitFor(() => other.text() === 'sigue vivo', 'servidor operativo');
    expect(server.stats().connections).toBeGreaterThan(0);
  });

  it('mensajes malformados o de texto cierran con 4400', async () => {
    const { url } = await boot();
    for (const payload of [new Uint8Array([99]), new Uint8Array([0, 7, 1, 2, 3]), 'texto' as const]) {
      const raw = rawSocket(url, newId());
      await raw.opened;
      raw.ws.send(payload);
      expect((await raw.closed).code).toBe(4400);
    }
  });

  it('rechaza ids inválidos (400) y orígenes no permitidos (403)', async () => {
    const { url } = await boot({ allowedOrigins: ['https://ok.example', '.app.github.dev'], allowNoOrigin: false });
    const id = newId();
    const status = async (path: string, headers: Record<string, string>) => {
      const raw = rawSocket(url, path, headers);
      try {
        await raw.opened;
        raw.ws.close();
        return 101;
      } catch (e) {
        return (e as { status?: number }).status ?? -1;
      }
    };
    expect(await status(id, { Origin: 'https://ok.example' })).toBe(101);
    expect(await status(id, { Origin: 'https://abc-5173.app.github.dev' })).toBe(101);
    expect(await status(id, { Origin: 'https://evil.example' })).toBe(403);
    expect(await status(id, {})).toBe(403); // sin Origin y allowNoOrigin=false
    expect(await status('no-es-uuid', { Origin: 'https://ok.example' })).toBe(400);
    expect(await status('..%2F..%2Fetc', { Origin: 'https://ok.example' })).toBe(400);
  });

  it('limita conexiones por sala y número de salas', async () => {
    const { url } = await boot({ maxConnectionsPerRoom: 2, maxRooms: 2 });
    const id = newId();
    const r1 = rawSocket(url, id);
    const r2 = rawSocket(url, id);
    await Promise.all([r1.opened, r2.opened]);
    const r3 = rawSocket(url, id);
    await r3.opened;
    expect((await r3.closed).code).toBe(1013);

    const other = rawSocket(url, newId());
    await other.opened; // segunda sala: permitida
    const third = rawSocket(url, newId());
    await third.opened;
    expect((await third.closed).code).toBe(1013); // tercera sala: rechazada
    for (const r of [r1, r2, other]) r.ws.close();
  });

  it('reenvía la presencia a la sala, remitente incluido (mantiene viva la conexión del cliente)', async () => {
    const { url } = await boot();
    const id = newId();
    const a = rawSocket(url, id);
    const b = rawSocket(url, id);
    await Promise.all([a.opened, b.opened]);
    const got = (r: ReturnType<typeof rawSocket>) =>
      new Promise<Uint8Array>((res) => {
        r.ws.on('message', (d: Buffer) => {
          if (d[0] === 1) res(new Uint8Array(d));
        });
      });
    const ga = got(a);
    const gb = got(b);
    a.ws.send(new Uint8Array([1, 2, 3, 4]));
    expect(await ga).toEqual(new Uint8Array([1, 2, 3, 4])); // eco al remitente
    expect(await gb).toEqual(new Uint8Array([1, 2, 3, 4])); // y a los demás
    a.ws.close();
    b.ws.close();
  });

  it('limita la tasa de mensajes por conexión (4529, transitorio)', async () => {
    const { url } = await boot({ maxMessagesPerSecond: 5 });
    const raw = rawSocket(url, newId());
    await raw.opened;
    const awareness = new Uint8Array([1, 0]);
    for (let i = 0; i < 30; i++) raw.ws.send(awareness);
    expect((await raw.closed).code).toBe(4529);
  });

  it('un cliente que supera la tasa NO queda rechazado: reconecta solo (el cierre es transitorio)', async () => {
    const { url } = await boot({ maxMessagesPerSecond: 20 });
    const id = newId();
    const a = track(makeClient(url, id, 200));
    const b = track(makeClient(url, id, 200));
    await Promise.all([whenSynced(a), whenSynced(b)]);
    for (let i = 0; i < 100; i++) a.doc.getText('content').insert(a.doc.getText('content').length, 'x'); // ráfaga
    await waitFor(() => a.text() === b.text() && a.text().length === 100, 'convergen tras la ráfaga', 10_000);
    expect(a.state().link).not.toBe('rejected');
  });

  it('el cierre ordenado desconecta a los clientes con 1001', async () => {
    const { url, server } = await boot();
    const raw = rawSocket(url, newId());
    await raw.opened;
    const closing = server.close();
    expect((await raw.closed).code).toBe(1001);
    await closing;
    servers.length = 0;
  });
});
