import { describe, expect, it } from 'vitest';
import { isOriginAllowed, parseDocId } from '../src/validation';
import { loadConfig } from '../src/config';

describe('parseDocId', () => {
  const id = '3f2b8c1e-5d4a-4b7e-9a21-0c8d6e4f1a2b';
  it('acepta exactamente /<uuid> y normaliza a minúsculas', () => {
    expect(parseDocId(`/${id}`)).toBe(id);
    expect(parseDocId(`/${id.toUpperCase()}`)).toBe(id);
  });
  it.each([undefined, '', '/', `/${id}/extra`, `/${id}?x=1`, '/../etc/passwd', '/nota-1', `//${id}`, `/${id}%00`])(
    'rechaza %s',
    (u) => expect(parseDocId(u as string | undefined)).toBeNull(),
  );
});

describe('isOriginAllowed', () => {
  const allowed = ['https://relay.ejemplo.com', '.app.github.dev'];
  it('admite orígenes exactos y sufijos https', () => {
    expect(isOriginAllowed('https://relay.ejemplo.com', allowed, false)).toBe(true);
    expect(isOriginAllowed('https://abc-5173.app.github.dev', allowed, false)).toBe(true);
  });
  it('rechaza otros, http en sufijos, orígenes mal formados y ausencia de Origin si no se permite', () => {
    expect(isOriginAllowed('https://evil.example', allowed, false)).toBe(false);
    expect(isOriginAllowed('http://abc.app.github.dev', allowed, false)).toBe(false);
    expect(isOriginAllowed('https://relay.ejemplo.com.evil.io', allowed, false)).toBe(false);
    expect(isOriginAllowed('https://relay.ejemplo.com/', allowed, false)).toBe(false);
    expect(isOriginAllowed('not a url', allowed, false)).toBe(false);
    expect(isOriginAllowed(undefined, allowed, false)).toBe(false);
    expect(isOriginAllowed(undefined, allowed, true)).toBe(true);
  });
});

describe('loadConfig', () => {
  it('en producción exige ALLOWED_ORIGINS y prohíbe "*"', () => {
    expect(() => loadConfig({ NODE_ENV: 'production' })).toThrow(/ALLOWED_ORIGINS/);
    expect(() => loadConfig({ NODE_ENV: 'production', ALLOWED_ORIGINS: '*' })).toThrow(/no admite/);
    const c = loadConfig({ NODE_ENV: 'production', ALLOWED_ORIGINS: 'https://a.example' });
    expect(c.allowedOrigins).toEqual(['https://a.example']);
    expect(c.allowNoOrigin).toBe(false);
  });
  it('rechaza números inválidos', () => {
    expect(() => loadConfig({ MAX_ROOMS: 'abc' })).toThrow(/MAX_ROOMS/);
    expect(() => loadConfig({ MAX_ROOMS: '0' })).toThrow(/MAX_ROOMS/);
  });
});
