import * as Y from 'yjs';
const gc = (globalThis as { gc?: () => void }).gc;
if (!gc) throw new Error('ejecuta con --expose-gc');
const name = process.env.SCEN as string;
const chars = Number(process.env.CHARS);
let seed = 5;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
const word = (n: number) => Array.from({ length: n }, () => 'abcdefghij klmnopqrstuvwxyz'[Math.floor(rnd() * 27)]).join('');
const heap = () => { for (let i = 0; i < 4; i++) gc(); return process.memoryUsage().heapUsed; };
const base = heap();
const content = name === 'pegado' ? word(chars) : '';
const doc = new Y.Doc();
const t = doc.getText('t');
if (name === 'pegado') t.insert(0, content);
if (name === 'tecleo') while (t.length < chars) t.insert(t.length, word(3));
if (name === 'ediciones al azar') while (t.length < chars) t.insert(Math.floor(rnd() * (t.length + 1)), word(5));
if (name === 'muchos borrados') {
  while (t.length < chars * 3) t.insert(Math.floor(rnd() * (t.length + 1)), word(5));
  while (t.length > chars) { const p = Math.floor(rnd() * t.length); t.delete(p, Math.min(6, t.length - p, t.length - chars)); }
}
const used = heap() - base - (name === 'pegado' ? 0 : 0);
const len = t.length; // mantener `doc` vivo hasta aquí
console.log(`| ${name} | ${len.toLocaleString('es')} | ${(used / 1024 / 1024).toFixed(2)} MiB | ${(used / len).toFixed(0)} B |`);
void doc;
