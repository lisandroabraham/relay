import * as Y from 'yjs';
import { makeClient, newId, startServer, waitFor, whenSynced } from '../tests/helpers';

const pct = (xs: number[], p: number) => [...xs].sort((a, b) => a - b)[Math.min(xs.length - 1, Math.floor((p / 100) * xs.length))] as number;
const f = (n: number) => n.toFixed(2);

const { url, server } = await startServer({ maxMessageBytes: 16 * 1024 * 1024, maxMessagesPerSecond: 1_000_000 });

// 1. Latencia de una pulsación A -> B (localhost, 1 servidor, 2 clientes)
{
  const id = newId();
  const a = makeClient(url, id);
  const b = makeClient(url, id);
  await Promise.all([whenSynced(a), whenSynced(b)]);
  const samples: number[] = [];
  for (let i = 0; i < 400; i++) {
    const arrived = new Promise<number>((res) => {
      const h = () => { b.doc.off('update', h); res(performance.now()); };
      b.doc.on('update', h);
    });
    const t0 = performance.now();
    a.doc.getText('content').insert(a.doc.getText('content').length, 'x');
    samples.push((await arrived) - t0);
  }
  const warm = samples.slice(50);
  console.error(`LATENCIA pulsación A→B (350 muestras tras calentar): p50 ${f(pct(warm, 50))} ms · p95 ${f(pct(warm, 95))} ms · máx ${f(Math.max(...warm))} ms`);
  a.stop(); b.stop();
}

// 2. Cliente que se une tarde a un documento grande
console.error('| Estado del documento | Tiempo hasta recibir el estado completo |\n|---:|---:|');
for (const chars of [100_000, 500_000, 2_000_000]) {
  const id = newId();
  const a = makeClient(url, id);
  await whenSynced(a);
  a.doc.getText('content').insert(0, 'abcdefghij'.repeat(chars / 10));
  const kib = Y.encodeStateAsUpdate(a.doc).byteLength / 1024;
  await new Promise((r) => setTimeout(r, 300)); // que el servidor lo reciba
  const t0 = performance.now();
  const late = makeClient(url, id);
  await waitFor(() => late.text().length === chars, 'cliente tardío', 20000);
  console.error(`| ${chars.toLocaleString('es')} caracteres (${kib.toFixed(0)} KiB) | ${f(performance.now() - t0)} ms |`);
  a.stop(); late.stop();
}

// 3. Convergencia tras trabajar ambos sin conexión
for (const ops of [200, 2000]) {
  const id = newId();
  const a = makeClient(url, id);
  const b = makeClient(url, id);
  await Promise.all([whenSynced(a), whenSynced(b)]);
  a.doc.getText('content').insert(0, 'base '.repeat(200));
  await waitFor(() => b.text() === a.text(), 'base');
  a.session.setPaused(true); b.session.setPaused(true);
  let seed = 99;
  const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
  for (const c of [a, b]) {
    const t = c.doc.getText('content');
    for (let i = 0; i < ops; i++) {
      if (t.length > 50 && rnd() < 0.3) t.delete(Math.floor(rnd() * (t.length - 5)), 1 + Math.floor(rnd() * 4));
      else t.insert(Math.floor(rnd() * (t.length + 1)), 'wxyz'[Math.floor(rnd() * 4)] as string);
    }
  }
  const t0 = performance.now();
  a.session.setPaused(false); b.session.setPaused(false);
  await waitFor(() => a.text() === b.text() && a.state().serverStateReceived && b.state().serverStateReceived, 'convergencia', 30000);
  console.error(`CONVERGENCIA tras ${ops} operaciones sin conexión en cada lado (texto final ${a.text().length} car.): ${f(performance.now() - t0)} ms desde reconectar`);
  a.stop(); b.stop();
}
await server.close();
process.exit(0);
