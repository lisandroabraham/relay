import * as Y from 'yjs';

const rnd = (() => { let a = 12345; return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; })();
const chunk = (n: number) => Array.from({ length: n }, () => 'abcdefghij klmnopqrstuvwxyz\n'[Math.floor(rnd() * 28)]).join('');

function scenario(name: string, chars: number): { doc: Y.Doc; ops: number } {
  const doc = new Y.Doc();
  const t = doc.getText('t');
  let ops = 0;
  if (name === 'pegado') { t.insert(0, chunk(chars)); ops = 1; }
  if (name === 'tecleo') { while (t.length < chars) { t.insert(t.length, chunk(1 + Math.floor(rnd() * 3))); ops++; } }
  if (name === 'ediciones al azar') { while (t.length < chars) { t.insert(Math.floor(rnd() * (t.length + 1)), chunk(1 + Math.floor(rnd() * 8))); ops++; } }
  if (name === 'con muchos borrados') {
    while (t.length < chars * 3) { t.insert(Math.floor(rnd() * (t.length + 1)), chunk(5)); ops++; }
    while (t.length > chars) { const p = Math.floor(rnd() * t.length); t.delete(p, Math.min(6, t.length - p, t.length - chars)); ops++; }
  }
  return { doc, ops };
}

const gc = (globalThis as { gc?: () => void }).gc;
if (process.env.HEADER) console.log('| Escenario | Caracteres | Operaciones | Estado completo | Bytes/carácter | Codificar | Aplicar en réplica nueva |');
if (process.env.HEADER) console.log('|---|---:|---:|---:|---:|---:|---:|');
const only = process.env.SCEN as string;
const sizes: Record<string, number[]> = {
  'pegado': [10_000, 100_000, 500_000],
  'tecleo': [10_000, 100_000, 500_000],
  'ediciones al azar': [10_000, 50_000, 150_000],
  'con muchos borrados': [10_000, 30_000, 60_000],
};
for (const name of [only]) {
  for (const chars of sizes[name] as number[]) {
    const { doc, ops } = scenario(name, chars);
    const len = doc.getText('t').length;
    let t0 = performance.now();
    const update = Y.encodeStateAsUpdate(doc);
    const enc = performance.now() - t0;
    t0 = performance.now();
    const fresh = new Y.Doc();
    Y.applyUpdate(fresh, update);
    const app = performance.now() - t0;
    if (fresh.getText('t').toString() !== doc.getText('t').toString()) throw new Error('réplica distinta');
    console.log(`| ${name} | ${len.toLocaleString('es')} | ${ops.toLocaleString('es')} | ${(update.byteLength / 1024).toFixed(1)} KiB | ${(update.byteLength / len).toFixed(2)} | ${enc.toFixed(1)} ms | ${app.toFixed(1)} ms |`);
  }
}
void gc;
