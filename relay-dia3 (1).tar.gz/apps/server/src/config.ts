export interface ServerConfig {
  port: number;
  host: string;
  /** Tamaño máximo de un mensaje WebSocket. Si se supera, ws cierra con 1009. */
  maxMessageBytes: number;
  maxConnections: number;
  maxRooms: number;
  maxConnectionsPerRoom: number;
  /** Tamaño máximo real (estado codificado de Yjs) de un documento en una sala. */
  maxRoomStateBytes: number;
  /** Cada cuántos bytes recibidos en una sala se mide el tamaño real del estado (0 = en cada mensaje). */
  stateCheckIntervalBytes: number;
  maxMessagesPerSecond: number;
  /** Orígenes exactos ("https://app.ejemplo.com") o sufijos de host (".app.github.dev"). */
  allowedOrigins: string[];
  /** Los navegadores siempre envían Origin; los clientes que no lo envían solo se admiten si esto es true. */
  allowNoOrigin: boolean;
  heartbeatMs: number;
  quiet: boolean;
}

export const CLOSE_MALFORMED = 4400;
export const CLOSE_TOO_LARGE = 4413;
// 4500-4599 = "inténtalo más tarde": el cliente reintenta con espera progresiva (no es un rechazo permanente).
export const CLOSE_RATE_LIMIT = 4529;

const DEV_ORIGINS = ['http://localhost:5173', 'http://127.0.0.1:5173', '.app.github.dev'];

function int(env: NodeJS.ProcessEnv, name: string, fallback: number, min = 1): number {
  const raw = env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min) throw new Error(`${name} debe ser un entero >= ${min}`);
  return n;
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): ServerConfig {
  const production = env.NODE_ENV === 'production';
  const rawOrigins = (env.ALLOWED_ORIGINS ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  if (rawOrigins.includes('*')) {
    throw new Error('ALLOWED_ORIGINS no admite "*": lista los orígenes permitidos.');
  }
  if (production && rawOrigins.length === 0) {
    throw new Error('En producción ALLOWED_ORIGINS es obligatorio.');
  }
  return {
    port: int(env, 'PORT', 1234, 0),
    host: env.HOST ?? (production ? '0.0.0.0' : '127.0.0.1'),
    maxMessageBytes: int(env, 'MAX_MESSAGE_BYTES', 4 * 1024 * 1024),
    maxConnections: int(env, 'MAX_CONNECTIONS', 200),
    maxRooms: int(env, 'MAX_ROOMS', 100),
    maxConnectionsPerRoom: int(env, 'MAX_CONNECTIONS_PER_ROOM', 20),
    maxRoomStateBytes: int(env, 'MAX_ROOM_STATE_BYTES', 8 * 1024 * 1024),
    stateCheckIntervalBytes: int(env, 'STATE_CHECK_INTERVAL_BYTES', 64 * 1024, 0),
    maxMessagesPerSecond: int(env, 'MAX_MESSAGES_PER_SECOND', 200),
    allowedOrigins: rawOrigins.length > 0 ? rawOrigins : production ? [] : DEV_ORIGINS,
    allowNoOrigin: env.ALLOW_NO_ORIGIN === 'true' || !production,
    heartbeatMs: int(env, 'HEARTBEAT_MS', 30_000),
    quiet: false,
  };
}
