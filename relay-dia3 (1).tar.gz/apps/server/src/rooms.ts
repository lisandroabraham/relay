import * as Y from 'yjs';
import type { WebSocket } from 'ws';

export class Room {
  readonly doc = new Y.Doc();
  readonly conns = new Set<WebSocket>();
  bytesSinceStateCheck = 0;
  constructor(readonly id: string) {}
}

export type JoinResult = { ok: true; room: Room } | { ok: false; reason: 'rooms_full' | 'room_full' };

/**
 * Salas en memoria. El servidor NO es fuente de verdad: cuando la última conexión de una sala se
 * cierra, la sala se destruye. El estado vive en los clientes (IndexedDB) y se restituye al
 * reconectar mediante el intercambio de estado de Yjs.
 */
export class RoomManager {
  private rooms = new Map<string, Room>();
  constructor(
    private readonly maxRooms: number,
    private readonly maxConnectionsPerRoom: number,
  ) {}

  get size(): number {
    return this.rooms.size;
  }

  join(id: string, ws: WebSocket, onCreate: (room: Room) => void): JoinResult {
    let room = this.rooms.get(id);
    if (!room) {
      if (this.rooms.size >= this.maxRooms) return { ok: false, reason: 'rooms_full' };
      room = new Room(id);
      this.rooms.set(id, room);
      onCreate(room);
    }
    if (room.conns.size >= this.maxConnectionsPerRoom) return { ok: false, reason: 'room_full' };
    room.conns.add(ws);
    return { ok: true, room };
  }

  leave(room: Room, ws: WebSocket): void {
    room.conns.delete(ws);
    if (room.conns.size === 0) {
      room.doc.destroy();
      this.rooms.delete(room.id);
    }
  }
}
