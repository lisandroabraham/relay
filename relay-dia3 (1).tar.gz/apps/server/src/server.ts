import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { WebSocket, WebSocketServer, type RawData } from 'ws';
import * as Y from 'yjs';
import * as encoding from 'lib0/encoding';
import * as decoding from 'lib0/decoding';
import * as syncProtocol from 'y-protocols/sync';
import {
  CLOSE_MALFORMED,
  CLOSE_RATE_LIMIT,
  CLOSE_TOO_LARGE,
  type ServerConfig,
} from './config';
import { RoomManager, type Room } from './rooms';
import { isOriginAllowed, parseDocId } from './validation';

const MESSAGE_SYNC = 0;
const MESSAGE_AWARENESS = 1;
const MESSAGE_QUERY_AWARENESS = 3;

export interface RelayServer {
  listen(): Promise<number>;
  close(): Promise<void>;
  stats(): { connections: number; rooms: number };
}

type Log = (event: string, fields?: Record<string, string | number | boolean>) => void;

/** Los logs registran eventos operativos, nunca el contenido de los documentos. */
function makeLog(quiet: boolean): Log {
  return (event, fields = {}) => {
    if (!quiet) console.log(JSON.stringify({ t: new Date().toISOString(), event, ...fields }));
  };
}

function toBytes(data: RawData): Uint8Array {
  if (Buffer.isBuffer(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  if (Array.isArray(data)) return new Uint8Array(Buffer.concat(data));
  return new Uint8Array(data);
}

function reject(socket: import('node:stream').Duplex, status: number, text: string): void {
  socket.write(`HTTP/1.1 ${status} ${text}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
  socket.destroy();
}

export function createRelayServer(config: ServerConfig): RelayServer {
  const log = makeLog(config.quiet);
  const rooms = new RoomManager(config.maxRooms, config.maxConnectionsPerRoom);
  let connections = 0;

  const httpServer = http.createServer((req, res) => {
    if (req.url === '/health') {
      res.writeHead(200, { 'Content-Type': 'text/plain' }).end('ok');
      return;
    }
    res.writeHead(404).end();
  });

  const wss = new WebSocketServer({ noServer: true, maxPayload: config.maxMessageBytes });

  function broadcastUpdates(room: Room): void {
    room.doc.on('update', (update: Uint8Array, origin: unknown) => {
      const encoder = encoding.createEncoder();
      encoding.writeVarUint(encoder, MESSAGE_SYNC);
      syncProtocol.writeUpdate(encoder, update);
      const msg = encoding.toUint8Array(encoder);
      for (const c of room.conns) {
        if (c !== origin && c.readyState === WebSocket.OPEN) c.send(msg);
      }
    });
  }

  httpServer.on('upgrade', (req, socket, head) => {
    const origin = req.headers.origin;
    if (!isOriginAllowed(origin, config.allowedOrigins, config.allowNoOrigin)) {
      log('reject', { reason: 'origin' });
      return reject(socket, 403, 'Forbidden');
    }
    const docId = parseDocId(req.url);
    if (!docId) {
      log('reject', { reason: 'bad_doc_id' });
      return reject(socket, 400, 'Bad Request');
    }
    if (connections >= config.maxConnections) {
      log('reject', { reason: 'max_connections' });
      return reject(socket, 503, 'Service Unavailable');
    }
    wss.handleUpgrade(req, socket, head, (ws) => onConnection(ws, docId));
  });

  function onConnection(ws: WebSocket, docId: string): void {
    const joined = rooms.join(docId, ws, broadcastUpdates);
    if (!joined.ok) {
      log('reject', { reason: joined.reason });
      ws.close(1013, 'try again later');
      return;
    }
    const room = joined.room;
    connections += 1;
    log('connect', { connections, rooms: rooms.size });

    let alive = true;
    let windowStart = Date.now();
    let windowCount = 0;
    ws.on('pong', () => {
      alive = true;
    });
    const heartbeat = setInterval(() => {
      if (!alive) {
        ws.terminate();
        return;
      }
      alive = false;
      ws.ping();
    }, config.heartbeatMs);

    ws.on('message', (data, isBinary) => {
      if (!isBinary) return ws.close(CLOSE_MALFORMED, 'binary only');
      const now = Date.now();
      if (now - windowStart >= 1000) {
        windowStart = now;
        windowCount = 0;
      }
      if (++windowCount > config.maxMessagesPerSecond) {
        log('close', { reason: 'rate_limit' });
        return ws.close(CLOSE_RATE_LIMIT, 'rate limit');
      }
      const bytes = toBytes(data);
      try {
        handleMessage(room, ws, bytes);
      } catch {
        log('close', { reason: 'malformed' });
        ws.close(CLOSE_MALFORMED, 'malformed message');
      }
    });

    ws.on('error', () => ws.terminate());
    ws.on('close', () => {
      clearInterval(heartbeat);
      connections -= 1;
      rooms.leave(room, ws);
      log('disconnect', { connections, rooms: rooms.size });
    });

    // Paso 1 del protocolo de sincronización: el servidor anuncia lo que tiene.
    const encoder = encoding.createEncoder();
    encoding.writeVarUint(encoder, MESSAGE_SYNC);
    syncProtocol.writeSyncStep1(encoder, room.doc);
    ws.send(encoding.toUint8Array(encoder));
  }

  function handleMessage(room: Room, ws: WebSocket, bytes: Uint8Array): void {
    const decoder = decoding.createDecoder(bytes);
    const type = decoding.readVarUint(decoder);
    switch (type) {
      case MESSAGE_SYNC: {
        const encoder = encoding.createEncoder();
        encoding.writeVarUint(encoder, MESSAGE_SYNC);
        syncProtocol.readSyncMessage(decoder, encoder, room.doc, ws);
        if (encoding.length(encoder) > 1) ws.send(encoding.toUint8Array(encoder));
        // El tamaño del estado de Yjs no es proporcional al texto (ver docs/BENCHMARKS.md), así que
        // se mide el estado real cada cierto volumen de tráfico, no se cuentan bytes acumulados.
        room.bytesSinceStateCheck += bytes.byteLength;
        if (room.bytesSinceStateCheck >= config.stateCheckIntervalBytes) {
          room.bytesSinceStateCheck = 0;
          if (Y.encodeStateAsUpdate(room.doc).byteLength > config.maxRoomStateBytes) {
            log('close', { reason: 'room_state_too_large' });
            ws.close(CLOSE_TOO_LARGE, 'document too large');
          }
        }
        return;
      }
      case MESSAGE_AWARENESS: {
        // Se reenvía tal cual a toda la sala, remitente incluido. Importante: el cliente
        // (y-websocket) cierra la conexión si pasan 30 s sin recibir ningún mensaje y cuenta con
        // recibir el eco de sus propias actualizaciones de presencia (cada 15 s).
        // El servidor no interpreta ni guarda la presencia.
        for (const c of room.conns) if (c.readyState === WebSocket.OPEN) c.send(bytes);
        return;
      }
      case MESSAGE_QUERY_AWARENESS:
        return; // El servidor no guarda estados de presencia: no hay nada que responder.
      default:
        throw new Error('unknown message type');
    }
  }

  return {
    listen: () =>
      new Promise<number>((resolve, reject) => {
        httpServer.once('error', reject);
        httpServer.listen(config.port, config.host, () => {
          httpServer.off('error', reject);
          resolve((httpServer.address() as AddressInfo).port);
        });
      }),
    close: () =>
      new Promise<void>((resolve) => {
        for (const c of wss.clients) c.close(1001, 'server shutting down');
        wss.close();
        httpServer.close(() => resolve());
        // Si algún cliente no cierra a tiempo, se corta.
        setTimeout(() => {
          for (const c of wss.clients) c.terminate();
          httpServer.closeAllConnections();
        }, 1000).unref();
      }),
    stats: () => ({ connections, rooms: rooms.size }),
  };
}
