import { loadConfig } from './config';
import { createRelayServer } from './server';

const config = loadConfig();
const server = createRelayServer(config);
const port = await server.listen();
console.log(
  JSON.stringify({
    event: 'listening',
    port,
    host: config.host,
    allowedOrigins: config.allowedOrigins,
  }),
);

let closing = false;
for (const sig of ['SIGINT', 'SIGTERM'] as const) {
  process.on(sig, () => {
    if (closing) return;
    closing = true;
    console.log(JSON.stringify({ event: 'shutdown', signal: sig }));
    void server.close().then(() => process.exit(0));
  });
}
