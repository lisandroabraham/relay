const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

/** La URL de conexión debe ser exactamente "/<uuid>". Devuelve el id en minúsculas o null. */
export function parseDocId(url: string | undefined): string | null {
  if (!url) return null;
  const m = /^\/([^/?#]+)$/.exec(url);
  const id = m?.[1]?.toLowerCase();
  return id && UUID_RE.test(id) ? id : null;
}

export function isOriginAllowed(
  origin: string | undefined,
  allowed: readonly string[],
  allowNoOrigin: boolean,
): boolean {
  if (origin === undefined) return allowNoOrigin;
  let url: URL;
  try {
    url = new URL(origin);
  } catch {
    return false;
  }
  if (url.origin !== origin) return false; // normalizado: sin ruta ni barra final
  return allowed.some((rule) =>
    rule.startsWith('.') ? url.protocol === 'https:' && url.hostname.endsWith(rule) : rule === origin,
  );
}
